print('safe')
