This is an ordinary project readme.
