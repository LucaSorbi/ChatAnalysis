# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-14)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Ultimo commit tracciato**: `6c1dc468c4d2fe94e9fcf0963aa36fc48bc9568b`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 conforme).

---

## 2. File Modificati Tracciati

I seguenti file contengono modifiche rispetto a `HEAD`:

- `ai/__init__.py`: Esportazione componenti operativi token-aware, listener e planner.
- `ai/backend.py`: Gestione unificata errori backend, categorizzazione HTTP 400 (CONTEXT_OVERFLOW, INVALID_ARGUMENT, SCHEMA_REJECTED) e token limit.
- `ai/chunking.py`:
  - Algoritmo token-aware con stima metadati evidenze (`estimate_evidence_framing_tokens`).
  - Normalizzazione morfologica italiana (`canonicalize_topic_label`) con preservazione dell'ordine sintattico per evitare fusioni semantiche improprie.
  - Funzione `profile_document_for_analysis` aggiornata per supportare `max_topics` e `profile`.
- `ai/lmstudio.py`:
  - Integrazione listener richieste HTTP reale (`request_listener`) per tracciamento granulare del ciclo di vita: `record_request_sent`, `record_http_response_received`, `record_request_success`, `record_http_error`, `record_timeout`, `record_protocol_error`.
  - Diagnostica HTTP 400 e rilevamento risposte JSON troncate (`finish_reason == "length"`).
- `ai/models.py`: Preservazione evidenze, metadati strutturali e provenance immutabile.
- `ai/topics.py`: Topic detector e analyzer operativi con supporto listener e error classification.
- `analysis/__init__.py`: Esportazione di `InsufficientContextHeadroomError` e `OperationalProfile`.
- `analysis/models.py`:
  - Introduzione profili operativi espliciti: `PRUDENT` (2500 tok), `BALANCED` (4200 tok), `PERFORMANCE` (5200 tok).
  - Funzione `resolve_operational_profile()` con verifica headroom reale: rimozione del fallback fittizio `max(256, available_headroom)` e sollevamento dell'errore tipizzato `InsufficientContextHeadroomError` quando headroom < 256.
  - Dataclass immutabile `AnalysisPlan`.
- `analysis/service.py`:
  - Caching preventivo del piano di analisi (`_analysis_plan_cache`) per evitare ri-chunking ripetuti su rerun Streamlit.
  - Disaccoppiamento dell'identificativo effimero di sessione LM Studio (`loaded_instance_id`) dall'identità stabile del modello (`resolved_model_key`, `quantization`, context length, prompt version, schema, limiti chunking) nel fingerprint di configurazione.
  - Revalidazione forense per-blocco (`chunks=chunks`) per intercettare attribuzioni indebite cross-chunk degli evidence ID.
  - Connessione del tracker alle richieste HTTP reali del client via listener.
  - Recupero incrementale chunk validati con zero richieste LLM ripetute.
- `analysis/checkpoint.py`:
  - Implementazione SQLite transazionale incrementale con modalità WAL, directory `0o700` e database file `0o600`.
  - Inserimento incrementale O(1) del singolo chunk validato (nessuna riscrittura dell'intero JSON).
  - Gestione deterministica delle connessioni SQLite con context manager (`_connect`), garantendo commit automatico, rollback su errore e chiusura immediata per prevenire lock di file su Windows.
  - Separazione di `loaded_instance_id` dal calcolo di `compute_run_config_hash`.
  - Revalidazione granulare cross-chunk (`validate_checkpoint_evidence_references(..., chunks=chunks)`).
  - Metodo `clear_for_document(doc)` con supporto a ConversationEvidenceDocument, fingerprint SHA-256 e document_id, con conteggio effettivo e protezione assoluta da cancellazioni indiscriminate della directory.
- `ui/state.py`:
  - Gestione stato sessione per profilo operativo (`KEY_OPERATIONAL_PROFILE`) e store di checkpoint (`KEY_CHECKPOINT_STORE`).
- `ui/application.py`:
  - Factory `get_operational_analysis_service()` abilitata con checkpointing reale (`AnalysisCheckpointStore`) e profilo selezionato.
  - Propagazione del profilo ai flussi di Detection, Discovery e Prova del Nove.
- `ui/presentation.py`:
  - Selettore profili operativi con spiegazione limiti, headroom check reale e gestione `InsufficientContextHeadroomError`.
  - Pulsante per eliminazione controllata dei checkpoint del documento tramite `chk_store.clear_for_document(doc)` con messaggio di conferma veritiero.
  - Profilazione preventiva e stima inferenze allineata dinamicamente a `disc_max_topics` (3, 10, 25 topic).
  - Visualizzazione avanzamento dettagliato: richieste inviate, riuscite, fallite, retry, in corso, chunk recuperati da checkpoint.
- `tests/unit/test_apptest_flows.py`:
  - Integrazione fixture di pulizia checkpoint temporanei per test isolati.
- `tests/unit/test_packaging_release.py`:
  - Test validazione wheel costruita con verifica di `analysis/checkpoint.py` e `analysis/progress.py`.

---

## 3. Nuovi Moduli e File Introdotti

- `tests/unit/test_checkpoint_integrity_scalability.py`:
  - Suite di test completa per la verifica dei 16 requisiti obbligatori di integrità checkpoint, ripresa dopo riavvio, persistenza incrementale, scalabilità e diagnostica.
- `scripts/benchmark_checkpoint_persistence.py`:
  - Script quantitativo e riproducibile di persistenza che misura e confronta SQLite incrementale vs Legacy JSON su 100, 1.000 e 10.000 chunk sintetici.
- `benchmark_checkpoint_persistence_results.json`:
  - Risultati empirici salvati del benchmark di persistenza.
- `scripts/generate_checkpoint_integrity_scalability_patch_utf8.py`:
  - Script deterministico per generazione patch Git unificata UTF-8 conforme.
- `scripts/package_checkpoint_integrity_scalability_zip.py`:
  - Script per packaging dell'archivio di consegna e calcolo del manifest SHA-256.

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati toccati e i loro hash SHA-256 corrispondono esattamente:

| File | SHA256 Attuale | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
