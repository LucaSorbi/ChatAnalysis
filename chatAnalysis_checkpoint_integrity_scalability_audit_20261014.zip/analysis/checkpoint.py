"""
analysis/checkpoint.py
----------------------
Meccanismo sicuro di Checkpoint e Ripresa per analisi tematiche estese (Topic Detection e Topic Discovery).

Principi architetturali e forensi:
1. IDENTIFICAZIONE CRITTOGRAFICA UNILATERALE (Document Fingerprint):
   Ciascun checkpoint è associato in modo univoco al fingerprint SHA-256 del documento analizzato
   (hash dei testi originali delle evidenze, message_id ed evidence_id). Nessuna cache o checkpoint
   può mai essere condiviso o scambiato tra documenti differenti.
2. CONFIG PROVENANCE RIGOROSA (Run Config Fingerprint):
   Memorizza modello (model_id), versione del prompt (prompt_version), schema e parametri di chunking
   (context_length, caratteri, token, temperature, seed). Se la configurazione cambia, il checkpoint precedente
   non viene considerato valido e viene avviata una nuova elaborazione coerente.
3. SALVATAGGIO POST-VALIDAZIONE ED ELABORAZIONE INCREMENTALE:
   I risultati dei chunk intermedi vengono salvati nel checkpoint ESCLUSIVAMENTE dopo la validazione formale
   del payload JSON e delle evidenze citate. In caso di ripresa, i chunk già validati non vengono rieseguiti.
4. PROTEZIONE LOCALE DEI DATI INVESTIGATIVI:
   I checkpoint risiedono esclusivamente nel filesystem protetto locale (nessuna trasmissione esterna).
   La scrittura avviene in modo atomico (file temporaneo + replace) per scongiurare corruzioni di stato
   in caso di terminazione improvvisa del processo.
5. ANNULLAMENTO E RIPRESA CONTROLLATI:
   In caso di interruzione (manuale o crash), lo stato salvato garantisce la ripresa trasparente dall'ultimo
   chunk completato, riducendo a zero il tempo di calcolo sprecato per conversazioni da centinaia di megabyte.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import threading
from typing import Any, Mapping, Sequence

from ai.models import (
    ConversationEvidenceDocument,
    DiscoveredTopic,
    TopicDecision,
    TopicDetectionResult,
    TopicDiscoveryResult,
    TopicQuery,
)
from analysis.models import OperationalAnalysisConfig


def compute_document_fingerprint(document: ConversationEvidenceDocument) -> str:
    """
    Calcola un digest crittografico SHA-256 del documento e delle sue evidenze forensi.
    Include esplicitamente timestamp e ordine dei messaggi, sender, identificativi e testi delle evidenze.
    Garantisce che qualsiasi alterazione di testo, timestamp, ordine o metadati modifichi il fingerprint.
    """
    hasher = hashlib.sha256()
    hasher.update(document.document_id.encode("utf-8"))
    hasher.update(str(document.chat_id or "").encode("utf-8"))
    hasher.update(str(document.source_name or "").encode("utf-8"))

    for idx, bundle in enumerate(document.bundles):
        hasher.update(f"idx:{idx}".encode("utf-8"))
        hasher.update(bundle.message.message_id.encode("utf-8"))
        hasher.update(str(bundle.message.timestamp or "").encode("utf-8"))
        hasher.update(str(bundle.message.sender or "").encode("utf-8"))
        for s_idx, sec in enumerate(bundle.text_evidence_sections):
            hasher.update(f"sec_idx:{s_idx}".encode("utf-8"))
            hasher.update(sec.evidence_id.encode("utf-8"))
            hasher.update(str(sec.source_record_id or "").encode("utf-8"))
            hasher.update(str(sec.language or "").encode("utf-8"))
            hasher.update(sec.text.encode("utf-8"))

    return hasher.hexdigest()


def compute_run_config_hash(
    model_id: str,
    prompt_version: str,
    config: OperationalAnalysisConfig | None = None,
    topic_query: TopicQuery | None = None,
    extra_params: Mapping[str, Any] | None = None,
    chunks: Sequence[ConversationEvidenceDocument] | None = None,
) -> str:
    """
    Calcola l'hash univoco e rigoroso dei parametri operativi e del modello per la run.
    Dipende dai parametri realmente usati: modello, quantizzazione, context length,
    temperature, seed, max output tokens, max topics per discovery, strategia,
    prompt e versione, schema, limiti di chunking, profilo e identità dei chunk.
    Separa l'identificativo volatile della sessione LM Studio (loaded_instance_id)
    dall'identità stabile del modello, consentendo la ripresa legittima dopo il riavvio del server.
    """
    cfg = config or OperationalAnalysisConfig()
    prof_val = cfg.profile.value if hasattr(cfg.profile, "value") else str(cfg.profile)
    payload: dict[str, Any] = {
        "model_id": model_id,
        "prompt_version": prompt_version,
        "context_length": cfg.context_length,
        "chunk_character_budget": cfg.chunk_character_budget,
        "max_chunk_bundles": cfg.max_chunk_bundles,
        "max_chunk_tokens": cfg.max_chunk_tokens,
        "temperature": cfg.temperature,
        "seed": cfg.seed,
        "profile": prof_val,
        "max_tokens": cfg.max_tokens,
        "max_topics": cfg.max_topics,
    }
    if topic_query is not None:
        payload["topic_id"] = topic_query.topic_id
        payload["topic_label"] = topic_query.label
        payload["topic_description"] = topic_query.description
        payload["is_label_only"] = getattr(topic_query, "is_label_only", False)
    if chunks is not None:
        payload["chunk_count"] = len(chunks)
        payload["chunk_ids"] = [c.document_id for c in chunks]
    if extra_params:
        # Separa l'identificativo volatile della sessione LM Studio dall'identità stabile del modello
        clean_extra = {k: v for k, v in extra_params.items() if k != "loaded_instance_id"}
        payload["extra"] = clean_extra

    serialized = json.dumps(payload, sort_keys=True)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def validate_checkpoint_evidence_references(
    checkpoint: AnalysisCheckpoint,
    document: ConversationEvidenceDocument,
    chunks: Sequence[ConversationEvidenceDocument] | None = None,
) -> bool:
    """
    Rivalida rigorosamente dopo il caricamento la struttura, la provenienza
    e la presenza di tutte le evidenze citate nel documento corrente.
    Se vengono forniti i blocchi pianificati (chunks), valida per ciascun blocco
    che ogni evidenza citata appartenga tassativamente al corrispondente blocco
    (rilevando manipolazioni o attribuzioni improprie cross-chunk).
    Se un checkpoint cita evidence_id inesistenti o appartiene a un altro documento,
    la validazione fallisce restituendo False.
    """
    if checkpoint.document_id != document.document_id:
        return False

    valid_doc_eids = {sec.evidence_id for sec in document.all_evidence_sections}

    for s_idx, s_data in checkpoint.serialized_results.items():
        try:
            chunk_num = int(s_idx)
        except (ValueError, TypeError):
            return False

        if chunks is not None:
            if chunk_num < 0 or chunk_num >= len(chunks):
                return False
            allowed_eids = {sec.evidence_id for sec in chunks[chunk_num].all_evidence_sections}
        else:
            allowed_eids = valid_doc_eids

        if checkpoint.analysis_type == "detection":
            eids = s_data.get("evidence_ids", ())
            for eid in eids:
                if eid not in allowed_eids:
                    return False
        elif checkpoint.analysis_type == "discovery":
            topics = s_data.get("topics", ())
            for t in topics:
                for eid in t.get("evidence_ids", ()):
                    if eid not in allowed_eids:
                        return False
    return True



@dataclass(frozen=True)
class AnalysisCheckpoint:
    """
    Rappresentazione immutabile dello stato di checkpoint salvato per una run.
    """
    document_id: str
    document_fingerprint: str
    config_fingerprint: str
    analysis_type: str  # "detection" | "discovery"
    model_id: str
    prompt_version: str
    total_planned_chunks: int
    completed_chunk_indices: tuple[int, ...]
    serialized_results: Mapping[str, Any]
    created_at: str
    updated_at: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "document_id": self.document_id,
            "document_fingerprint": self.document_fingerprint,
            "config_fingerprint": self.config_fingerprint,
            "analysis_type": self.analysis_type,
            "model_id": self.model_id,
            "prompt_version": self.prompt_version,
            "total_planned_chunks": self.total_planned_chunks,
            "completed_chunk_indices": list(self.completed_chunk_indices),
            "serialized_results": dict(self.serialized_results),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


def serialize_detection_result_for_checkpoint(result: TopicDetectionResult) -> dict[str, Any]:
    """Serializza deterministicamente un TopicDetectionResult validato."""
    return {
        "topic": {
            "topic_id": result.topic.topic_id,
            "label": result.topic.label,
            "description": result.topic.description,
            "is_label_only": getattr(result.topic, "is_label_only", False),
        },
        "decision": result.decision.value,
        "evidence_ids": list(result.evidence_ids),
        "rationale": result.rationale,
        "provenance_document_id": result.provenance_document_id,
        "metadata": dict(result.metadata),
    }


def deserialize_detection_result_from_checkpoint(data: dict[str, Any]) -> TopicDetectionResult:
    """Ricostruisce un TopicDetectionResult da checkpoint."""
    t_data = data["topic"]
    topic = TopicQuery(
        topic_id=t_data["topic_id"],
        label=t_data["label"],
        description=t_data.get("description", ""),
        is_label_only=t_data.get("is_label_only", False),
    )
    return TopicDetectionResult(
        topic=topic,
        decision=TopicDecision(data["decision"]),
        evidence_ids=tuple(data.get("evidence_ids", ())),
        rationale=data.get("rationale", ""),
        provenance_document_id=data.get("provenance_document_id", ""),
        metadata=dict(data.get("metadata", {})),
    )


def serialize_discovery_result_for_checkpoint(result: TopicDiscoveryResult) -> dict[str, Any]:
    """Serializza deterministicamente un TopicDiscoveryResult validato."""
    return {
        "topics": [
            {
                "label": t.label,
                "short_description": t.short_description,
                "evidence_ids": list(t.evidence_ids),
            }
            for t in result.topics
        ],
        "provenance_document_id": result.provenance_document_id,
        "metadata": dict(result.metadata),
    }


def deserialize_discovery_result_from_checkpoint(data: dict[str, Any]) -> TopicDiscoveryResult:
    """Ricostruisce un TopicDiscoveryResult da checkpoint."""
    topics = [
        DiscoveredTopic(
            label=t["label"],
            short_description=t.get("short_description", ""),
            evidence_ids=tuple(t.get("evidence_ids", ())),
        )
        for t in data.get("topics", ())
    ]
    return TopicDiscoveryResult(
        topics=tuple(topics),
        provenance_document_id=data.get("provenance_document_id", ""),
        metadata=dict(data.get("metadata", {})),
    )


class CheckpointSaveError(Exception):
    """Sollevata quando il salvataggio atomico del checkpoint su disco fallisce."""
    pass


class AnalysisCheckpointStore:
    """
    Gestore transazionale, incrementale e thread-safe dei checkpoint forensi su SQLite locale.
    Salva atomicamente soltanto il nuovo blocco validato (O(1)), evitando riscritture O(N^2).
    Include permessi restrittivi sulla directory (0o700) e sul file database (0o600).
    Supporta migrazione trasparente dai legacy checkpoint JSON e cancellazione controllata per documento.
    """

    def __init__(
        self,
        checkpoint_dir: str | Path | None = None,
        db_name: str = "checkpoints.db",
    ) -> None:
        if checkpoint_dir is None:
            self.checkpoint_dir = Path(".checkpoints")
        else:
            self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(self.checkpoint_dir, 0o700)
        except Exception:
            pass

        self.db_path = self.checkpoint_dir / db_name
        self._lock = threading.Lock()
        self._init_db()
        self._migrate_legacy_json_if_needed()

    def _init_db(self) -> None:
        """Inizializza le tabelle SQLite con modalità WAL e permessi restrittivi."""
        try:
            with self._connect() as conn:
                conn.execute("PRAGMA journal_mode=WAL;")
                conn.execute("PRAGMA synchronous=NORMAL;")
                conn.execute("PRAGMA foreign_keys=ON;")
                conn.execute("PRAGMA busy_timeout=5000;")

                conn.execute("""
                    CREATE TABLE IF NOT EXISTS checkpoints (
                        document_fingerprint TEXT NOT NULL,
                        config_fingerprint TEXT NOT NULL,
                        document_id TEXT NOT NULL,
                        analysis_type TEXT NOT NULL,
                        model_id TEXT NOT NULL,
                        prompt_version TEXT NOT NULL,
                        total_planned_chunks INTEGER NOT NULL,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        PRIMARY KEY (document_fingerprint, config_fingerprint)
                    );
                """)

                conn.execute("""
                    CREATE TABLE IF NOT EXISTS checkpoint_chunks (
                        document_fingerprint TEXT NOT NULL,
                        config_fingerprint TEXT NOT NULL,
                        chunk_index INTEGER NOT NULL,
                        serialized_result TEXT NOT NULL,
                        created_at TEXT NOT NULL,
                        PRIMARY KEY (document_fingerprint, config_fingerprint, chunk_index),
                        FOREIGN KEY (document_fingerprint, config_fingerprint)
                            REFERENCES checkpoints (document_fingerprint, config_fingerprint)
                            ON DELETE CASCADE
                    );
                """)

                conn.execute("""
                    CREATE INDEX IF NOT EXISTS idx_chunks_doc
                    ON checkpoint_chunks (document_fingerprint);
                """)

                conn.execute("""
                    CREATE INDEX IF NOT EXISTS idx_checkpoints_doc_id
                    ON checkpoints (document_id);
                """)

            if self.db_path.exists():
                try:
                    os.chmod(self.db_path, 0o600)
                except Exception:
                    pass
        except Exception:
            pass

    @contextmanager
    def _connect(self):
        """Restituisce una nuova connessione SQLite con gestione deterministica di commit, rollback e chiusura."""
        conn = sqlite3.connect(str(self.db_path), timeout=30.0, check_same_thread=False)
        try:
            conn.execute("PRAGMA foreign_keys=ON;")
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _migrate_legacy_json_if_needed(self) -> None:
        """Migra trasparentemente eventuali file checkpoint JSON preesistenti nel database SQLite."""
        try:
            json_files = list(self.checkpoint_dir.glob("chk_*.json"))
            if not json_files:
                return

            with self._connect() as conn:
                for jf in json_files:
                    try:
                        with open(jf, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        doc_fp = data.get("document_fingerprint")
                        cfg_fp = data.get("config_fingerprint")
                        if not doc_fp or not cfg_fp:
                            continue

                        doc_id = str(data.get("document_id", ""))
                        a_type = str(data.get("analysis_type", ""))
                        m_id = str(data.get("model_id", ""))
                        p_ver = str(data.get("prompt_version", ""))
                        t_chunks = int(data.get("total_planned_chunks", 0))
                        c_at = str(data.get("created_at", datetime.now(timezone.utc).isoformat()))
                        u_at = str(data.get("updated_at", c_at))

                        conn.execute("""
                            INSERT INTO checkpoints (
                                document_fingerprint, config_fingerprint, document_id,
                                analysis_type, model_id, prompt_version, total_planned_chunks,
                                created_at, updated_at
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ON CONFLICT(document_fingerprint, config_fingerprint) DO UPDATE SET
                                updated_at = excluded.updated_at,
                                total_planned_chunks = excluded.total_planned_chunks;
                        """, (doc_fp, cfg_fp, doc_id, a_type, m_id, p_ver, t_chunks, c_at, u_at))

                        s_results = data.get("serialized_results", {})
                        for s_idx, s_val in s_results.items():
                            c_idx = int(s_idx)
                            json_val = json.dumps(s_val, ensure_ascii=False)
                            conn.execute("""
                                INSERT INTO checkpoint_chunks (
                                    document_fingerprint, config_fingerprint, chunk_index,
                                    serialized_result, created_at
                                ) VALUES (?, ?, ?, ?, ?)
                                ON CONFLICT(document_fingerprint, config_fingerprint, chunk_index) DO UPDATE SET
                                    serialized_result = excluded.serialized_result;
                            """, (doc_fp, cfg_fp, c_idx, json_val, u_at))

                        try:
                            jf.unlink()
                        except Exception:
                            pass
                    except Exception:
                        pass
        except Exception:
            pass

    def _get_checkpoint_path(self, document_fingerprint: str, config_fingerprint: str) -> Path:
        """Percorso di compatibilità per test legacy."""
        safe_name = f"chk_{document_fingerprint[:16]}_{config_fingerprint[:16]}.json"
        return self.checkpoint_dir / safe_name

    def has_checkpoint(self, document_fingerprint: str, config_fingerprint: str) -> bool:
        """Verifica la presenza di un checkpoint con almeno un blocco salvato."""
        try:
            with self._connect() as conn:
                cur = conn.execute("""
                    SELECT 1 FROM checkpoint_chunks
                    WHERE document_fingerprint = ? AND config_fingerprint = ?
                    LIMIT 1;
                """, (document_fingerprint, config_fingerprint))
                if cur.fetchone() is not None:
                    return True
        except Exception:
            pass
        # Fallback su file legacy se presente
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        return p.is_file() and p.stat().st_size > 0

    def load_checkpoint(
        self,
        document_fingerprint: str,
        config_fingerprint: str,
    ) -> AnalysisCheckpoint | None:
        """
        Carica lo stato del checkpoint salvato per (document_fingerprint, config_fingerprint).
        Se non presente o corrotto, restituisce None senza sollevare eccezioni.
        """
        # 1. Controlla prima se è presente un file legacy (o corrotto per test)
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        if p.is_file():
            try:
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if data.get("document_fingerprint") != document_fingerprint or data.get("config_fingerprint") != config_fingerprint:
                    return None
                # Se è un file legacy valido, migra e restituisce
                self._migrate_legacy_json_if_needed()
            except Exception:
                # File corrotto -> rifiuto sicuro
                return None

        # 2. Caricamento da SQLite
        try:
            with self._connect() as conn:
                cur = conn.execute("""
                    SELECT document_id, analysis_type, model_id, prompt_version,
                           total_planned_chunks, created_at, updated_at
                    FROM checkpoints
                    WHERE document_fingerprint = ? AND config_fingerprint = ?;
                """, (document_fingerprint, config_fingerprint))
                main_row = cur.fetchone()
                if not main_row:
                    return None

                doc_id, a_type, m_id, p_ver, t_chunks, c_at, u_at = main_row

                chunk_cur = conn.execute("""
                    SELECT chunk_index, serialized_result
                    FROM checkpoint_chunks
                    WHERE document_fingerprint = ? AND config_fingerprint = ?
                    ORDER BY chunk_index ASC;
                """, (document_fingerprint, config_fingerprint))
                chunk_rows = chunk_cur.fetchall()
                if not chunk_rows:
                    return None

                completed_indices = []
                serialized_results = {}
                for c_idx, s_raw in chunk_rows:
                    completed_indices.append(int(c_idx))
                    serialized_results[str(c_idx)] = json.loads(s_raw)

                return AnalysisCheckpoint(
                    document_id=str(doc_id),
                    document_fingerprint=str(document_fingerprint),
                    config_fingerprint=str(config_fingerprint),
                    analysis_type=str(a_type),
                    model_id=str(m_id),
                    prompt_version=str(p_ver),
                    total_planned_chunks=int(t_chunks),
                    completed_chunk_indices=tuple(sorted(completed_indices)),
                    serialized_results=serialized_results,
                    created_at=str(c_at),
                    updated_at=str(u_at),
                )
        except Exception:
            return None

    def load_and_validate_checkpoint(
        self,
        document: ConversationEvidenceDocument,
        config_fingerprint: str,
        chunks: Sequence[ConversationEvidenceDocument] | None = None,
    ) -> AnalysisCheckpoint | None:
        """
        Carica e rivalida integralmente il checkpoint:
        1. Calcola il fingerprint crittografico del documento attuale;
        2. Carica i blocchi validati da SQLite;
        3. Rivalida che tutte le evidenze citate esistano e, se chunks è fornito,
           appartengano tassativamente allo specifico blocco di provenienza.
        """
        doc_fp = compute_document_fingerprint(document)
        chk = self.load_checkpoint(doc_fp, config_fingerprint)
        if chk is None:
            return None
        if not validate_checkpoint_evidence_references(chk, document, chunks=chunks):
            return None
        return chk

    def save_chunk(
        self,
        document_id: str,
        document_fingerprint: str,
        config_fingerprint: str,
        chunk_idx: int,
        result: TopicDetectionResult | TopicDiscoveryResult,
        total_planned_chunks: int,
        analysis_type: str,
        model_id: str,
        prompt_version: str,
    ) -> None:
        """
        Salva atomicamente il singolo blocco validato nel database SQLite (scrittura incrementale O(1)).
        Non rilegge né riscrive i blocchi precedenti, garantendo scalabilità su migliaia di chunk.
        """
        if isinstance(result, TopicDetectionResult):
            serialized_chunk = serialize_detection_result_for_checkpoint(result)
        elif isinstance(result, TopicDiscoveryResult):
            serialized_chunk = serialize_discovery_result_for_checkpoint(result)
        else:
            raise TypeError(f"Tipo risultato non supportato per checkpoint: {type(result)}")

        serialized_json = json.dumps(serialized_chunk, ensure_ascii=False)
        now_iso = datetime.now(timezone.utc).isoformat()

        try:
            with self._lock:
                with self._connect() as conn:
                    # Inserisce o aggiorna la testata checkpoint
                    conn.execute("""
                        INSERT INTO checkpoints (
                            document_fingerprint, config_fingerprint, document_id,
                            analysis_type, model_id, prompt_version, total_planned_chunks,
                            created_at, updated_at
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ON CONFLICT(document_fingerprint, config_fingerprint) DO UPDATE SET
                            updated_at = excluded.updated_at,
                            total_planned_chunks = excluded.total_planned_chunks;
                    """, (
                        document_fingerprint, config_fingerprint, document_id,
                        analysis_type, model_id, prompt_version, total_planned_chunks,
                        now_iso, now_iso,
                    ))

                    # Inserisce o aggiorna il singolo chunk
                    conn.execute("""
                        INSERT INTO checkpoint_chunks (
                            document_fingerprint, config_fingerprint, chunk_index,
                            serialized_result, created_at
                        ) VALUES (?, ?, ?, ?, ?)
                        ON CONFLICT(document_fingerprint, config_fingerprint, chunk_index) DO UPDATE SET
                            serialized_result = excluded.serialized_result;
                    """, (
                        document_fingerprint, config_fingerprint, chunk_idx,
                        serialized_json, now_iso,
                    ))
        except Exception as exc:
            raise CheckpointSaveError(f"Impossibile salvare il chunk {chunk_idx} in SQLite: {exc}") from exc

    def clear_checkpoint(self, document_fingerprint: str, config_fingerprint: str) -> bool:
        """Elimina il checkpoint una volta conclusa con successo l'analisi complessiva."""
        deleted = False
        try:
            with self._lock:
                with self._connect() as conn:
                    cur = conn.execute("""
                        DELETE FROM checkpoints
                        WHERE document_fingerprint = ? AND config_fingerprint = ?;
                    """, (document_fingerprint, config_fingerprint))
                    if cur.rowcount > 0:
                        deleted = True
        except Exception:
            pass

        # Pulisce anche eventuale file legacy
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        if p.is_file():
            try:
                p.unlink()
                deleted = True
            except OSError:
                pass
        return deleted

    def clear_for_document(
        self,
        document_or_fingerprint_or_id: ConversationEvidenceDocument | str,
    ) -> int:
        """
        Cancellazione controllata e sicura di tutti i checkpoint appartenenti ESCLUSIVAMENTE al documento indicato.
        Accetta un oggetto ConversationEvidenceDocument, un fingerprint SHA-256 (64 hex) o un document_id.
        Non permette MAI la cancellazione indiscriminata dell'intera directory né di altri documenti.
        Restituisce il conteggio esatto dei checkpoint rimossi.
        """
        if isinstance(document_or_fingerprint_or_id, ConversationEvidenceDocument):
            doc_fp = compute_document_fingerprint(document_or_fingerprint_or_id)
            doc_id = document_or_fingerprint_or_id.document_id
        elif isinstance(document_or_fingerprint_or_id, str):
            val = document_or_fingerprint_or_id.strip()
            if len(val) == 64 and all(c in "0123456789abcdefABCDEF" for c in val):
                doc_fp = val.lower()
                doc_id = ""
            else:
                doc_fp = ""
                doc_id = val
        else:
            return 0

        cleared_count = 0
        try:
            with self._lock:
                with self._connect() as conn:
                    if doc_fp and doc_id:
                        cur = conn.execute("""
                            DELETE FROM checkpoints
                            WHERE document_fingerprint = ? OR document_id = ?;
                        """, (doc_fp, doc_id))
                    elif doc_fp:
                        cur = conn.execute("""
                            DELETE FROM checkpoints
                            WHERE document_fingerprint = ?;
                        """, (doc_fp,))
                    elif doc_id:
                        cur = conn.execute("""
                            DELETE FROM checkpoints
                            WHERE document_id = ?;
                        """, (doc_id,))
                    else:
                        cur = None
                    cleared_count = cur.rowcount if cur else 0

                # Pulisce anche eventuali legacy json residui del documento specifico
                prefixes = []
                if doc_fp:
                    prefixes.append(f"chk_{doc_fp[:16]}_")
                if doc_id:
                    prefixes.append(f"chk_{doc_id[:16]}_")
                for prefix in prefixes:
                    for p in self.checkpoint_dir.glob(f"{prefix}*.json"):
                        try:
                            p.unlink()
                            cleared_count += 1
                        except OSError:
                            pass
        except Exception:
            pass
        return cleared_count

    def clear_all_for_document(self, document_fingerprint: str) -> int:
        """Alias retrocompatibile per clear_for_document."""
        return self.clear_for_document(document_fingerprint)

