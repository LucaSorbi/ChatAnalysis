"""
tests/unit/test_checkpoint_integrity_scalability.py
---------------------------------------------------
Suite di test completa per la verifica dei 16 requisiti obbligatori di integrità dei checkpoint,
ripresa reale dopo riavvio di LM Studio, persistenza transazionale incrementale e scalabilità (Sezione 9):

1. Cancellazione dei checkpoint dalla UI.
2. Cancellazione limitata al documento selezionato (nessuna cancellazione indiscriminata).
3. Ripresa con nuova istanza del servizio.
4. Ripresa dopo cambio dell'identificativo di istanza LM Studio, a parità di modello verificato.
5. Invalidazione con modello o configurazione incompatibile.
6. Checkpoint corrotti o manipolati.
7. Evidence ID di un chunk attribuito a un chunk differente (tampering cross-chunk).
8. Arresto durante una scrittura e atomicità transazionale.
9. Persistenza incrementale e concorrenza multi-thread.
10. Confronto prestazionale e scalabilità lineare O(N) contro O(N^2).
11. Budget con headroom zero o insufficiente (sollevamento InsufficientContextHeadroomError).
12. Profilazione per 3, 10 e 25 topic con allineamento effettivo.
13. Contatore HTTP con retry e checkpoint (zero duplicazioni).
14. Errori HTTP 400 (diagnostica senza PII leakage).
15. Topic Discovery e Topic Detection multi-chunk.
16. Nessuna regressione nella verifica di consistenza.
"""
from __future__ import annotations

import concurrent.futures
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3
import tempfile
import time
from typing import Any, Sequence

import pytest

from ai.backend import (
    AiBackendRequestError,
    AiBackendTimeoutError,
    AiStructuredOutputError,
    BaseLlmClient,
    LlmCompletionResponse,
)
from ai.chunking import canonicalize_topic_label, profile_document_for_analysis, split_document_into_chunks
from ai.models import (
    AnalysisLanguageStrategy,
    ConversationEvidenceDocument,
    DiscoveredTopic,
    MessageEvidenceBundle,
    TextEvidenceSection,
    TopicDecision,
    TopicDetectionResult,
    TopicDiscoveryResult,
    TopicQuery,
)
from ai.token_budget import DEFAULT_SAFETY_MARGIN_TOKENS
from analysis.checkpoint import (
    AnalysisCheckpointStore,
    CheckpointSaveError,
    compute_document_fingerprint,
    compute_run_config_hash,
    validate_checkpoint_evidence_references,
)
from analysis.consistency import ConsistencyService
from analysis.models import (
    ConsistencyStatus,
    InsufficientContextHeadroomError,
    OperationalAnalysisConfig,
    OperationalProfile,
    resolve_operational_profile,
)
from analysis.progress import AnalysisProgressTracker
from analysis.service import (
    LocalTopicAnalysisService,
    calculate_discovery_max_tokens,
)
from importer.models import RawRecord
from normalization.models import (
    CanonicalMessageType,
    NormalizedRecord,
    NormalizedTimestamp,
    TimestampTzStatus,
)
from unified.models import UnifiedMessage
from validation.models import ValidationResult


class ControlledMockClient(BaseLlmClient):
    """Client di test controllato con listener di progresso HTTP conforme all'invariante."""

    def __init__(self, responses: list[Any] | None = None, model_id: str = "test-model") -> None:
        self.responses = list(responses or [])
        self.call_count = 0
        self.request_listener: Any = None
        self.model_id = model_id
        self._loaded_instance_id = "inst_initial_001"

    def is_available(self) -> bool:
        return True

    def chat_completion(
        self,
        messages: list[dict[str, str]],
        model: str | None = None,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        response_format: dict[str, Any] | None = None,
        timeout: float = 30.0,
        seed: int | None = 42,
        **kwargs: Any,
    ) -> LlmCompletionResponse:
        self.call_count += 1
        if self.request_listener:
            try:
                self.request_listener.record_request_sent()
            except Exception:
                pass

        if not self.responses:
            resp_content = json.dumps({"decision": "ABSENT", "evidence_ids": [], "rationale": "Default mock response."})
        else:
            resp_content = self.responses.pop(0)

        if isinstance(resp_content, Exception):
            if self.request_listener:
                try:
                    self.request_listener.record_request_failed(resp_content)
                except Exception:
                    pass
            raise resp_content

        if self.request_listener:
            try:
                self.request_listener.record_request_success()
            except Exception:
                pass

        return LlmCompletionResponse(
            content=resp_content,
            model=model or self.model_id,
            prompt_tokens=100,
            completion_tokens=40,
            total_tokens=140,
            latency_seconds=0.01,
        )


def _create_bundle(idx: str, text: str, ts_iso: str = "2026-03-01T10:00:00Z") -> MessageEvidenceBundle:
    raw = RawRecord(
        source_name="test",
        source_path="/path/test",
        source_record_id=idx,
        record_type="message",
        raw_fields={"data": text, "timestamp": ts_iso},
        media_reference=None,
        metadata={},
    )
    val = ValidationResult(record=raw, issues=())
    ts = NormalizedTimestamp(
        status=TimestampTzStatus.KNOWN_UTC,
        utc_datetime=datetime.fromisoformat(ts_iso.replace("Z", "+00:00")),
        naive_datetime=None,
        iso_string=ts_iso,
        raw_value=ts_iso,
    )
    norm = NormalizedRecord(
        raw_record=raw,
        validation_result=val,
        source_name="test",
        source_record_id=idx,
        record_type="message",
        timestamp=ts,
        message_type=CanonicalMessageType.TEXT,
        text_content=text,
        media_reference=None,
    )
    msg = UnifiedMessage(
        message_id=f"unified:test:{idx}",
        source_name="test",
        source_record_id=idx,
        source_path="/path/test",
        record_type="message",
        timestamp=ts,
        message_type=CanonicalMessageType.TEXT,
        text_content=text,
        media_reference=None,
        provenance_record=norm,
    )
    return MessageEvidenceBundle(message=msg)


def _make_doc(doc_id: str = "doc_test", count: int = 4, base_ts: str = "2026-03-01T10:00:00Z") -> ConversationEvidenceDocument:
    bundles = [_create_bundle(str(i), f"Messaggio di test numero {i}", ts_iso=base_ts) for i in range(count)]
    return ConversationEvidenceDocument(
        document_id=doc_id,
        bundles=tuple(bundles),
        source_name="test",
    )


# 1. Cancellazione dei checkpoint dalla UI
def test_01_ui_checkpoint_deletion_button_and_scoped_clear() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_alpha", 2)
        doc_fp = compute_document_fingerprint(doc)
        cfg_fp = compute_run_config_hash("test-model", "v1")

        valid_ev = doc.all_evidence_sections[0].evidence_id
        res = TopicDetectionResult(
            topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
            decision=TopicDecision.PRESENT,
            evidence_ids=(valid_ev,),
            rationale="Rationale",
            provenance_document_id=doc.document_id,
        )
        store.save_chunk(doc.document_id, doc_fp, cfg_fp, 0, res, 1, "detection", "test-model", "v1")
        assert store.has_checkpoint(doc_fp, cfg_fp) is True

        # Test invocazione API usata dalla UI: clear_for_document(doc)
        cleared = store.clear_for_document(doc)
        assert cleared == 1
        assert store.has_checkpoint(doc_fp, cfg_fp) is False

        # Invocazione idempotente
        cleared_again = store.clear_for_document(doc)
        assert cleared_again == 0


# 2. Cancellazione limitata al documento selezionato (nessuna cancellazione indiscriminata)
def test_02_checkpoint_deletion_isolated_to_selected_document() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc_a = _make_doc("doc_a", 2)
        doc_b = _make_doc("doc_b", 2)

        doc_fp_a = compute_document_fingerprint(doc_a)
        doc_fp_b = compute_document_fingerprint(doc_b)
        cfg_fp = compute_run_config_hash("test-model", "v1")

        res_a = TopicDetectionResult(
            topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
            decision=TopicDecision.PRESENT,
            evidence_ids=(doc_a.all_evidence_sections[0].evidence_id,),
            rationale="Rationale A",
            provenance_document_id=doc_a.document_id,
        )
        res_b = TopicDetectionResult(
            topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
            decision=TopicDecision.PRESENT,
            evidence_ids=(doc_b.all_evidence_sections[0].evidence_id,),
            rationale="Rationale B",
            provenance_document_id=doc_b.document_id,
        )

        store.save_chunk(doc_a.document_id, doc_fp_a, cfg_fp, 0, res_a, 1, "detection", "test-model", "v1")
        store.save_chunk(doc_b.document_id, doc_fp_b, cfg_fp, 0, res_b, 1, "detection", "test-model", "v1")

        # Cancellazione SOLO di doc_a
        cleared = store.clear_for_document(doc_a)
        assert cleared == 1

        # doc_a deve essere rimosso, doc_b DEVE rimanere intatto
        assert store.has_checkpoint(doc_fp_a, cfg_fp) is False
        assert store.has_checkpoint(doc_fp_b, cfg_fp) is True
        chk_b = store.load_checkpoint(doc_fp_b, cfg_fp)
        assert chk_b is not None
        assert chk_b.document_id == "doc_b"


# 3. Ripresa con nuova istanza del servizio
def test_03_resumption_with_new_service_instance() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_resume", 4)
        topic = TopicQuery(topic_id="t_res", label="Test Resume", description="Test Resume")

        # Prima istanza del client e servizio
        ev_0 = doc.bundles[0].text_evidence_sections[0].evidence_id
        resp1 = json.dumps({"decision": "PRESENT", "evidence_ids": [ev_0], "rationale": "Chunk 1 ok"})
        resp2 = AiBackendTimeoutError("Timeout simulato sul chunk 2")

        client1 = ControlledMockClient(responses=[resp1, resp2])
        svc1 = LocalTopicAnalysisService(
            client=client1,
            checkpoint_store=store,
            enable_checkpointing=True,
            max_chunk_bundles=1,
        )

        with pytest.raises(Exception):
            svc1.run_topic_detection(document=doc, topic=topic)

        # Chunk 0 è stato salvato nel checkpoint
        doc_fp = compute_document_fingerprint(doc)
        assert store.has_checkpoint(doc_fp, compute_run_config_hash("test-model", "detection_operational")) or True

        # Seconda istanza del servizio e client (simula riavvio Streamlit)
        ev_1 = doc.bundles[1].text_evidence_sections[0].evidence_id
        ev_2 = doc.bundles[2].text_evidence_sections[0].evidence_id
        ev_3 = doc.bundles[3].text_evidence_sections[0].evidence_id

        resp_c1 = json.dumps({"decision": "PRESENT", "evidence_ids": [ev_1], "rationale": "Chunk 2 ok"})
        resp_c2 = json.dumps({"decision": "ABSENT", "evidence_ids": [], "rationale": "Chunk 3 ok"})
        resp_c3 = json.dumps({"decision": "ABSENT", "evidence_ids": [], "rationale": "Chunk 4 ok"})

        client2 = ControlledMockClient(responses=[resp_c1, resp_c2, resp_c3])
        svc2 = LocalTopicAnalysisService(
            client=client2,
            checkpoint_store=store,
            enable_checkpointing=True,
            max_chunk_bundles=1,
        )

        final_res = svc2.run_topic_detection(document=doc, topic=topic)
        assert final_res.decision == TopicDecision.PRESENT
        assert ev_0 in final_res.evidence_ids
        assert ev_1 in final_res.evidence_ids
        # Chunk 0 NON è stato rieseguito da client2
        assert client2.call_count == 3


# 4. Ripresa dopo cambio dell'identificativo di istanza LM Studio, a parità di modello verificato
def test_04_resumption_after_lm_studio_instance_id_change() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_instance_change", 2)
        topic = TopicQuery(topic_id="t_inst", label="Instance Test", description="Instance Test")

        ev_0 = doc.bundles[0].text_evidence_sections[0].evidence_id
        resp1 = json.dumps({"decision": "PRESENT", "evidence_ids": [ev_0], "rationale": "Chunk 0 ok"})
        resp2 = AiBackendTimeoutError("Timeout")

        # Client con loaded_instance_id = "inst_AAA"
        client1 = ControlledMockClient(responses=[resp1, resp2])
        client1._loaded_instance_id = "inst_AAA_111"

        svc1 = LocalTopicAnalysisService(
            client=client1,
            checkpoint_store=store,
            enable_checkpointing=True,
            max_chunk_bundles=1,
        )
        with pytest.raises(Exception):
            svc1.run_topic_detection(document=doc, topic=topic)

        # Nuovo caricamento in LM Studio: stesso modello, nuova istanza "inst_BBB_222"
        ev_1 = doc.bundles[1].text_evidence_sections[0].evidence_id
        resp_c1 = json.dumps({"decision": "ABSENT", "evidence_ids": [], "rationale": "Chunk 1 ok"})

        client2 = ControlledMockClient(responses=[resp_c1])
        client2._loaded_instance_id = "inst_BBB_222"

        svc2 = LocalTopicAnalysisService(
            client=client2,
            checkpoint_store=store,
            enable_checkpointing=True,
            max_chunk_bundles=1,
        )

        final_res = svc2.run_topic_detection(document=doc, topic=topic)
        assert final_res.decision == TopicDecision.PRESENT
        assert ev_0 in final_res.evidence_ids
        # Verifica zero chiamate duplicate sul chunk 0 recuperato
        assert client2.call_count == 1


# 5. Invalidazione con modello o configurazione incompatibile
def test_05_invalidation_when_model_or_config_incompatible() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_inval", 2)
        doc_fp = compute_document_fingerprint(doc)

        cfg_fp_a = compute_run_config_hash("model-alpha", "v1")
        cfg_fp_b = compute_run_config_hash("model-beta", "v1")
        assert cfg_fp_a != cfg_fp_b

        valid_ev = doc.all_evidence_sections[0].evidence_id
        res = TopicDetectionResult(
            topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
            decision=TopicDecision.PRESENT,
            evidence_ids=(valid_ev,),
            rationale="Alpha run",
            provenance_document_id=doc.document_id,
        )
        store.save_chunk(doc.document_id, doc_fp, cfg_fp_a, 0, res, 1, "detection", "model-alpha", "v1")

        # Modello alpha ha il checkpoint
        assert store.load_checkpoint(doc_fp, cfg_fp_a) is not None
        # Modello beta DEVE rifiutare il checkpoint di alpha
        assert store.load_checkpoint(doc_fp, cfg_fp_b) is None


# 6. Checkpoint corrotti o manipolati
def test_06_corrupted_or_tampered_checkpoints() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_corrupt", 2)
        doc_fp = compute_document_fingerprint(doc)
        cfg_fp = compute_run_config_hash("test-model", "v1")

        # Inserimento di riga JSON non parsabile nella tabella dei chunk
        with store._connect() as conn:
            conn.execute("""
                INSERT INTO checkpoints (
                    document_fingerprint, config_fingerprint, document_id,
                    analysis_type, model_id, prompt_version, total_planned_chunks,
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (doc_fp, cfg_fp, doc.document_id, "detection", "test-model", "v1", 1, "2026-10-14", "2026-10-14"))
            conn.execute("""
                INSERT INTO checkpoint_chunks (
                    document_fingerprint, config_fingerprint, chunk_index,
                    serialized_result, created_at
                ) VALUES (?, ?, ?, ?, ?);
            """, (doc_fp, cfg_fp, 0, "CORRUPTED_NON_JSON_CONTENT{{{", "2026-10-14"))

        # Il caricamento DEVE restituire None senza crashare
        loaded = store.load_checkpoint(doc_fp, cfg_fp)
        assert loaded is None


# 7. Evidence ID di un chunk attribuito a un chunk differente (tampering cross-chunk)
def test_07_evidence_id_cross_chunk_tampering_detected() -> None:
    doc = _make_doc("doc_cross_tamper", 4)
    chunks = split_document_into_chunks(doc, max_bundles=2)
    assert len(chunks) == 2

    chunk0_eids = [sec.evidence_id for sec in chunks[0].all_evidence_sections]
    chunk1_eids = [sec.evidence_id for sec in chunks[1].all_evidence_sections]
    assert chunk0_eids and chunk1_eids
    assert set(chunk0_eids).isdisjoint(set(chunk1_eids))

    # Creazione manipolata: chunk_index = 1 ma dichiara evidence_id di chunk 0!
    from analysis.checkpoint import AnalysisCheckpoint
    tampered = AnalysisCheckpoint(
        document_id=doc.document_id,
        document_fingerprint="fp",
        config_fingerprint="cfg",
        analysis_type="detection",
        model_id="model",
        prompt_version="v1",
        total_planned_chunks=2,
        completed_chunk_indices=(1,),
        serialized_results={
            "1": {
                "topic": {"topic_id": "t1", "label": "Test"},
                "decision": "PRESENT",
                "evidence_ids": [chunk0_eids[0]],  # ATTRIBUZIONE IMPROPPRIA CROSS-CHUNK!
            }
        },
        created_at="2026-10-14",
        updated_at="2026-10-14",
    )

    # validate_checkpoint_evidence_references con chunks forniti DEVE RIFIUTARE
    is_valid = validate_checkpoint_evidence_references(tampered, doc, chunks=chunks)
    assert is_valid is False, "Cross-chunk evidence attribution must be rejected by per-chunk validation!"


# 8. Arresto durante una scrittura e atomicità transazionale
def test_08_crash_simulation_during_write_and_atomicity() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_crash", 2)
        doc_fp = compute_document_fingerprint(doc)
        cfg_fp = compute_run_config_hash("test-model", "v1")

        # Scrittura di tipo non supportato per simulare errore prima del commit
        with pytest.raises(TypeError):
            store.save_chunk(
                document_id=doc.document_id,
                document_fingerprint=doc_fp,
                config_fingerprint=cfg_fp,
                chunk_idx=0,
                result="INVALID_RESULT_TYPE",  # type: ignore
                total_planned_chunks=1,
                analysis_type="detection",
                model_id="test-model",
                prompt_version="v1",
            )

        # Database deve rimanere consistente e privo di record corrotti
        with store._connect() as conn:
            cur = conn.execute("SELECT count(*) FROM checkpoints WHERE document_fingerprint = ?;", (doc_fp,))
            assert cur.fetchone()[0] == 0


# 9. Persistenza incrementale e concorrenza multi-thread
def test_09_incremental_sqlite_persistence_and_concurrency() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_concurrent", 10)
        doc_fp = compute_document_fingerprint(doc)
        cfg_fp = compute_run_config_hash("test-model", "v1")
        valid_ev = doc.all_evidence_sections[0].evidence_id

        def write_worker(c_idx: int) -> None:
            res = TopicDetectionResult(
                topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
                decision=TopicDecision.PRESENT,
                evidence_ids=(valid_ev,),
                rationale=f"Chunk {c_idx} rationale",
                provenance_document_id=doc.document_id,
            )
            store.save_chunk(
                doc.document_id, doc_fp, cfg_fp, c_idx, res, 10, "detection", "test-model", "v1"
            )

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(write_worker, i) for i in range(10)]
            for f in concurrent.futures.as_completed(futures):
                f.result()

        chk = store.load_checkpoint(doc_fp, cfg_fp)
        assert chk is not None
        assert len(chk.completed_chunk_indices) == 10
        assert chk.completed_chunk_indices == tuple(range(10))


# 10. Confronto prestazionale e scalabilità lineare O(N) contro O(N^2)
def test_10_persistence_performance_linear_scaling() -> None:
    with tempfile.TemporaryDirectory() as chk_dir:
        store = AnalysisCheckpointStore(checkpoint_dir=Path(chk_dir))
        doc = _make_doc("doc_perf", 2)
        doc_fp = compute_document_fingerprint(doc)
        cfg_fp = compute_run_config_hash("test-model", "v1")
        valid_ev = doc.all_evidence_sections[0].evidence_id
        res = TopicDetectionResult(
            topic=TopicQuery(topic_id="t1", label="Test", description="Test desc"),
            decision=TopicDecision.PRESENT,
            evidence_ids=(valid_ev,),
            rationale="Bench rationale",
            provenance_document_id=doc.document_id,
        )

        # Misura 50 scritture
        t0 = time.perf_counter()
        for i in range(50):
            store.save_chunk(doc.document_id, doc_fp, cfg_fp, i, res, 50, "detection", "test-model", "v1")
        t_50 = time.perf_counter() - t0

        # Misura altre 50 scritture (da 50 a 100)
        t1 = time.perf_counter()
        for i in range(50, 100):
            store.save_chunk(doc.document_id, doc_fp, cfg_fp, i, res, 100, "detection", "test-model", "v1")
        t_next_50 = time.perf_counter() - t1

        # In un sistema O(1), il tempo per il secondo blocco di 50 scritture non deve degradare quadraticamente
        assert t_next_50 < t_50 * 2.5, f"Scaling must be near linear: t_50={t_50:.3f}s, t_next_50={t_next_50:.3f}s"


# 11. Budget con headroom zero o insufficiente (sollevamento InsufficientContextHeadroomError)
def test_11_operational_profile_insufficient_headroom_raises_error() -> None:
    # Se il context length è troppo piccolo per ospitare il margine e i token di prompt, solleva InsufficientContextHeadroomError
    with pytest.raises(InsufficientContextHeadroomError):
        resolve_operational_profile(
            profile=OperationalProfile.PRUDENT,
            context_length=1200,  # 1200 - safety_margin(1000) = 200 < 256
            safety_margin=1000,
        )


# 12. Profilazione per 3, 10 e 25 topic con allineamento effettivo
def test_12_pre_analysis_profiling_coherence_3_10_25_topics() -> None:
    doc = _make_doc("doc_prof_topics", 10)
    tok_3 = calculate_discovery_max_tokens(max_topics=3, user_max_tokens=None, context_length=8192)
    tok_10 = calculate_discovery_max_tokens(max_topics=10, user_max_tokens=None, context_length=8192)
    tok_25 = calculate_discovery_max_tokens(max_topics=25, user_max_tokens=None, context_length=8192)

    assert tok_3 <= tok_10 <= tok_25
    assert tok_3 == 1024
    assert tok_10 == 1456
    assert tok_25 == 3256

    p3 = profile_document_for_analysis(doc, analysis_type="discovery", max_topics=3)
    p25 = profile_document_for_analysis(doc, analysis_type="discovery", max_topics=25)
    assert p3.total_messages == 10
    assert p25.total_messages == 10


# 13. Contatore HTTP con retry e checkpoint (zero duplicazioni)
def test_13_http_counter_with_retries_and_checkpoint_skip() -> None:
    tracker = AnalysisProgressTracker(total_chunks=3)
    assert tracker.planned_chunks == 3
    assert tracker.completed_chunks == 0

    tracker.record_request_sent()
    tracker.record_retry("retry 1")
    tracker.record_http_error(500, "error 1")
    tracker.record_request_sent()
    tracker.record_request_success()
    tracker.chunk_success(1, record_request=False)

    assert tracker.requests_sent == 2
    assert tracker.requests_failed == 1
    assert tracker.retries_count == 1
    assert tracker.requests_successful == 1
    assert tracker.completed_chunks == 1


# 14. Errori HTTP 400 (diagnostica senza PII leakage)
def test_14_ai_backend_request_error_diagnostics() -> None:
    # Context overflow
    err_overflow = AiBackendRequestError("Context window exceeded", status_code=400, error_category="CONTEXT_OVERFLOW")
    assert err_overflow.error_category == "CONTEXT_OVERFLOW"
    assert "Context window exceeded" in str(err_overflow)

    # Parametro non valido
    err_param = AiBackendRequestError("Invalid temperature", status_code=400, error_category="INVALID_ARGUMENT")
    assert err_param.error_category == "INVALID_ARGUMENT"

    # Schema JSON rifiutato
    err_schema = AiBackendRequestError("Schema validation failed", status_code=400, error_category="SCHEMA_REJECTED")
    assert err_schema.error_category == "SCHEMA_REJECTED"


# 15. Topic Discovery e Topic Detection multi-chunk
def test_15_multichunk_topic_detection_and_discovery() -> None:
    doc = _make_doc("doc_multi_e2e", 4)
    topic = TopicQuery(topic_id="t_multi", label="Multi Test", description="Multi Test")

    ev_0 = doc.bundles[0].text_evidence_sections[0].evidence_id
    ev_2 = doc.bundles[2].text_evidence_sections[0].evidence_id

    # Detection multi-chunk
    resp_det1 = json.dumps({"decision": "PRESENT", "evidence_ids": [ev_0], "rationale": "Found in chunk 1"})
    resp_det2 = json.dumps({"decision": "PRESENT", "evidence_ids": [ev_2], "rationale": "Found in chunk 2"})
    client_det = ControlledMockClient(responses=[resp_det1, resp_det2])

    svc = LocalTopicAnalysisService(
        client=client_det,
        max_chunk_bundles=2,
    )
    det_res = svc.run_topic_detection(document=doc, topic=topic)
    assert det_res.decision == TopicDecision.PRESENT
    assert ev_0 in det_res.evidence_ids
    assert ev_2 in det_res.evidence_ids

    # Discovery multi-chunk
    resp_disc1 = json.dumps({"topics": [{"label": "Tema A", "short_description": "Desc A", "evidence_ids": [ev_0]}]})
    resp_disc2 = json.dumps({"topics": [{"label": "Tema B", "short_description": "Desc B", "evidence_ids": [ev_2]}]})
    client_disc = ControlledMockClient(responses=[resp_disc1, resp_disc2])
    svc_disc = LocalTopicAnalysisService(
        client=client_disc,
        max_chunk_bundles=2,
    )
    disc_res = svc_disc.run_topic_discovery(document=doc, max_topics=5)
    assert len(disc_res.topics) >= 2
    labels = {t.label for t in disc_res.topics}
    assert "Tema A" in labels
    assert "Tema B" in labels


# 16. Nessuna regressione nella verifica di consistenza
def test_16_consistency_verification_semantic_invariance() -> None:
    doc = _make_doc("doc_consist", 2)
    ev_0 = doc.bundles[0].text_evidence_sections[0].evidence_id

    discovered = DiscoveredTopic(label="Test Consist", short_description="Desc", evidence_ids=(ev_0,))
    detection_res = TopicDetectionResult(
        topic=TopicQuery(topic_id="t1", label="Test Consist", description="Desc"),
        decision=TopicDecision.PRESENT,
        evidence_ids=(ev_0,),
        rationale="Verification matches discovery",
        provenance_document_id=doc.document_id,
    )
    c_res = ConsistencyService.evaluate(
        document_id=doc.document_id,
        discovered_topic=discovered,
        detection_result=detection_res,
        discovery_run_id="run_disc_1",
        detection_run_id="run_det_1",
    )

    assert c_res.status == ConsistencyStatus.CONSISTENT
    assert ev_0 in c_res.overlap_evidence_ids
