# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-14)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Ultimo commit tracciato**: `6c1dc468c4d2fe94e9fcf0963aa36fc48bc9568b`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 conforme).

---

## 2. File Modificati Tracciati e Sintesi delle Correzioni

I seguenti file contengono modifiche rispetto a `HEAD`:

- `analysis/checkpoint.py`:
  - **Correzione 1 (Cancellazione Sicura)**: Il metodo `clear_for_document(doc)` ora filtra tassativamente solo per `document_fingerprint = ?`. È stata rimossa la clausola permissiva `OR document_id = ?`, eliminando alla radice le cancellazioni collaterali di versioni differenti dello stesso documento aventi stesso `document_id`. È stata introdotta l'API esplicita e separata `clear_all_for_document_id(document_id)` per la rimozione intenzionale cross-versione per ID leggibile.
  - **Correzione 2 (Validazione Completa Provenienza)**: `validate_checkpoint_evidence_references()` rivalida esaustivamente `document_id`, `document_fingerprint`, la corrispondenza del `provenance_document_id` per ciascun blocco (accettando solo il documento padre o il sotto-blocco atteso, e rifiutando tassativamente manipolazioni come `'FAKE_OTHER_DOCUMENT'`), l'aderenza all'analisi (`detection` vs `discovery`), la validità degli indici blocco, la compatibilità con la query topic (`expected_topic_query`) e la completezza strutturale senza default che mascherino campi obbligatori.
  - **Correzione 3 (Migrazione Sicura da JSON a SQLite)**: `_migrate_legacy_json_if_needed()` implementa un ciclo transazionale a 6 stadi: lettura, validazione strutturale, inserimento in transazione isolata, commit esplicito WAL, verifica di persistenza con `SELECT COUNT(*)`, e solo a fronte di esito positivo la rimozione sicura del file legacy JSON. In caso di errore o lock di database (`sqlite3.OperationalError`), la transazione viene annullata con rollback e il file originale rimane integro su disco.
  - **Correzione 7 (Sicurezza e Permessi)**: Configurazione PRAGMA SQLite esplicita su ogni connessione (`journal_mode=WAL`, `synchronous=NORMAL`, `foreign_keys=ON`, `busy_timeout=5000`). Applicazione e documentazione dei permessi restrittivi filesystem (`0o700` directory, `0o600` file database), chiarendo che tali permessi controllano l'accesso a livello OS ma non costituiscono crittografia trasparente dei dati a riposo.
- `analysis/service.py`:
  - Propagazione di `expected_topic_query=topic` e `expected_analysis_type="detection"` / `"discovery"` nelle chiamate a `chk_store.load_and_validate_checkpoint()` per garantire che checkpoint incompatibili per query o tipo non vengano mai recuperati.
  - Preservazione rigorosa del contatore HTTP: zero chiamate di rete o invocazioni a LM Studio per i chunk recuperati dal database SQLite.
- `scripts/benchmark_checkpoint_persistence.py`:
  - **Correzione 5 (Report Prestazionale Attendibile)**: Rimozione di valori costanti arbitrari (`t_json_est = 265.0`). Separazione netta tra misure sperimentali effettive (scale 100 e 1.000 chunk) e proiezioni matematiche analitiche ($O(N^2)$ giustificato teoricamente per 10.000 chunk legacy JSON). Tracciamento dell'ambiente di esecuzione (SO, filesystem, versione Python, configurazione SQLite WAL) e chiarimento esplicito che il benchmark misura il solo sottosistema di persistenza I/O e non il tempo di calcolo dell'inferenza GPU su GTX TITAN X.
- `benchmark_checkpoint_persistence_results.json`:
  - Dati quantitativi aggiornati con marcatore `"status": "NOT_MEASURED_PROHIBITIVE_IO"` per 10.000 chunk legacy JSON e dettagli della formula analitica.
- `tests/unit/test_checkpoint_integrity_scalability.py`:
  - **Correzione 4 (Test di Ripresa Realmente Significativi)**: Eliminazione della condizione tautologica `assert ... or True` e inserimento di verifiche dirette dell'esistenza del primo chunk nel database, dell'assenza dei chunk non completati, del recupero selettivo senza chiamate duplicate e del conteggio esatto delle interrogazioni (5 totali tra prima e seconda sessione).
  - Aggiunti test 17, 18, 19 e 20: cancellazione selettiva con stesso document_id, rifiuto di checkpoint con `provenance_document_id='FAKE_OTHER_DOCUMENT'` o mancante, migrazione legacy con rollback e database bloccato, e verifica delle impostazioni di durabilità WAL.

---

## 3. Risultati della Suite di Test

- **Pytest completo**: **1753 superati**, 1 saltato, 5 esclusi, **0 fallimenti** (in 194.45s).
- **Suite di Integrità e Scalabilità**: **20 su 20 superati** (in 11.75s).
- **Streamlit AppTest (`test_apptest_flows.py`)**: **7 su 7 superati** (in 14.67s).
- **Packaging e Integrità Wheel (`test_packaging_release.py`)**: **1 su 1 superato**.

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati modificati e i rispettivi hash SHA-256 corrispondono esattamente:

| File | SHA256 Attuale | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
