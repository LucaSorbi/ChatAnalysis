# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-13)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Ultimo commit tracciato**: `6c1dc468c4d2fe94e9fcf0963aa36fc48bc9568b`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8).

## 2. File Modificati Tracciati

I seguenti file contengono modifiche rispetto a `HEAD`:
- `ai/__init__.py`: Esportazione componenti operativi token-aware.
- `ai/backend.py`: Gestione unificata errori backend, categorizzazione overflow.
- `ai/chunking.py`: Algoritmo token-aware, stima metadati evidenze (`estimate_evidence_framing_tokens`), stem canonico italiano (`canonicalize_topic_label`, `stem_italian_word`), deduplicazione morfologica senza perdita di evidenze con `semantic_deduplication=False`.
- `ai/lmstudio.py`: Integrazione payload nativi e retry controllati.
- `ai/models.py`: Preservazione evidenze e metadati strutturali immutabili.
- `ai/topics.py`: Topic detector e resolver operativi.
- `analysis/models.py`: Modelli operativi, configurazioni di analisi e contabilità.
- `analysis/service.py`: Protezione budget headroom reale (nessun clamping fittizio `max(256, ...)`), integrazione store di checkpointing locale atomico, profilazione coerente pre-analisi (`profile_document`), contabilità richieste HTTP e gestione split sub-chunk.
- `tests/unit/test_packaging_release.py`: Build wheel isolata con `--no-build-isolation` locale.
- `ui/application.py`: Integrazione progress tracker esteso.
- `ui/presentation.py`: Profilazione preventiva delegata al service layer per detection e discovery; barra di avanzamento con contabilità dettagliata (in-flight, transport error, timeout, protocol error).

## 3. Nuovi Moduli Operativi Introdotti

- `analysis/checkpoint.py`: Meccanismo di checkpoint e ripresa atomico locale, isolato per documento (fingerprint crittografico SHA256 e configurazione), salvataggio atomico dei chunk validati, skip delle inferenze già completate.
- `tests/unit/test_performance_accounting_audit.py`: 12 test unitari dedicati ai 6 problemi dell'audit (invariante HTTP requests, split recovery, headroom reale, stima evidenze complesse/emoji/multilingue, coerenza profilo preventivo, isolamento checkpoint, skip chunk già completati, normalizzazione stem morfologica italiana, aggregazione su 2.273 blocchi).
- `scripts/measure_scalability_and_profiling.py`: Benchmark comparativo disaggregato su 4 configurazioni di chunking e consolidamento a scala reale.
- `scripts/package_final_performance_accounting_zip.py`: Script deterministico per generazione ZIP e `MANIFEST_SHA256.txt`.
- `scripts/generate_final_performance_accounting_patch_utf8.py`: Script per generazione patch Git unificata UTF-8.

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati toccati e i loro hash SHA256 corrispondono esattamente:

| File | SHA256 Attuale | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
