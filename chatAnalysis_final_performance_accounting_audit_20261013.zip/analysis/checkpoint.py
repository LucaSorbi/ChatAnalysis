"""
analysis/checkpoint.py
----------------------
Meccanismo sicuro di Checkpoint e Ripresa per analisi tematiche estese (Topic Detection e Topic Discovery).

Principi architetturali e forensi:
1. IDENTIFICAZIONE CRITTOGRAFICA UNILATERALE (Document Fingerprint):
   Ciascun checkpoint è associato in modo univoco al fingerprint SHA-256 del documento analizzato
   (hash dei testi originali delle evidenze, message_id ed evidence_id). Nessuna cache o checkpoint
   può mai essere condiviso o scambiato tra documenti differenti.
2. CONFIG PROVENANCE RIGOROSA (Run Config Fingerprint):
   Memorizza modello (model_id), versione del prompt (prompt_version), schema e parametri di chunking
   (context_length, caratteri, token, temperature, seed). Se la configurazione cambia, il checkpoint precedente
   non viene considerato valido e viene avviata una nuova elaborazione coerente.
3. SALVATAGGIO POST-VALIDAZIONE ED ELABORAZIONE INCREMENTALE:
   I risultati dei chunk intermedi vengono salvati nel checkpoint ESCLUSIVAMENTE dopo la validazione formale
   del payload JSON e delle evidenze citate. In caso di ripresa, i chunk già validati non vengono rieseguiti.
4. PROTEZIONE LOCALE DEI DATI INVESTIGATIVI:
   I checkpoint risiedono esclusivamente nel filesystem protetto locale (nessuna trasmissione esterna).
   La scrittura avviene in modo atomico (file temporaneo + replace) per scongiurare corruzioni di stato
   in caso di terminazione improvvisa del processo.
5. ANNULLAMENTO E RIPRESA CONTROLLATI:
   In caso di interruzione (manuale o crash), lo stato salvato garantisce la ripresa trasparente dall'ultimo
   chunk completato, riducendo a zero il tempo di calcolo sprecato per conversazioni da centinaia di megabyte.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import tempfile
from typing import Any, Mapping, Sequence

from ai.models import (
    ConversationEvidenceDocument,
    DiscoveredTopic,
    TopicDecision,
    TopicDetectionResult,
    TopicDiscoveryResult,
    TopicQuery,
)
from analysis.models import OperationalAnalysisConfig


def compute_document_fingerprint(document: ConversationEvidenceDocument) -> str:
    """
    Calcola un digest crittografico SHA-256 del documento e delle sue evidenze forensi.
    Garantisce che qualsiasi alterazione di testo, ordine o metadati modifichi il fingerprint.
    """
    hasher = hashlib.sha256()
    hasher.update(document.document_id.encode("utf-8"))
    hasher.update(str(document.chat_id or "").encode("utf-8"))
    hasher.update(str(document.source_name or "").encode("utf-8"))

    for bundle in document.bundles:
        hasher.update(bundle.message.message_id.encode("utf-8"))
        for sec in bundle.text_evidence_sections:
            hasher.update(sec.evidence_id.encode("utf-8"))
            hasher.update(str(sec.source_record_id or "").encode("utf-8"))
            hasher.update(str(sec.language or "").encode("utf-8"))
            hasher.update(sec.text.encode("utf-8"))

    return hasher.hexdigest()


def compute_run_config_hash(
    model_id: str,
    prompt_version: str,
    config: OperationalAnalysisConfig | None = None,
    topic_query: TopicQuery | None = None,
    extra_params: Mapping[str, Any] | None = None,
) -> str:
    """
    Calcola l'hash univoco dei parametri operativi e del modello per la run.
    """
    cfg = config or OperationalAnalysisConfig()
    payload = {
        "model_id": model_id,
        "prompt_version": prompt_version,
        "context_length": cfg.context_length,
        "chunk_character_budget": cfg.chunk_character_budget,
        "max_chunk_bundles": cfg.max_chunk_bundles,
        "max_chunk_tokens": cfg.max_chunk_tokens,
        "temperature": cfg.temperature,
        "seed": cfg.seed,
    }
    if topic_query is not None:
        payload["topic_id"] = topic_query.topic_id
        payload["topic_label"] = topic_query.label
        payload["topic_description"] = topic_query.description
    if extra_params:
        payload["extra"] = dict(extra_params)

    serialized = json.dumps(payload, sort_keys=True)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class AnalysisCheckpoint:
    """
    Rappresentazione immutabile dello stato di checkpoint salvato per una run.
    """
    document_id: str
    document_fingerprint: str
    config_fingerprint: str
    analysis_type: str  # "detection" | "discovery"
    model_id: str
    prompt_version: str
    total_planned_chunks: int
    completed_chunk_indices: tuple[int, ...]
    serialized_results: Mapping[str, Any]
    created_at: str
    updated_at: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "document_id": self.document_id,
            "document_fingerprint": self.document_fingerprint,
            "config_fingerprint": self.config_fingerprint,
            "analysis_type": self.analysis_type,
            "model_id": self.model_id,
            "prompt_version": self.prompt_version,
            "total_planned_chunks": self.total_planned_chunks,
            "completed_chunk_indices": list(self.completed_chunk_indices),
            "serialized_results": dict(self.serialized_results),
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }


def serialize_detection_result_for_checkpoint(result: TopicDetectionResult) -> dict[str, Any]:
    """Serializza deterministicamente un TopicDetectionResult validato."""
    return {
        "topic": {
            "topic_id": result.topic.topic_id,
            "label": result.topic.label,
            "description": result.topic.description,
            "is_label_only": getattr(result.topic, "is_label_only", False),
        },
        "decision": result.decision.value,
        "evidence_ids": list(result.evidence_ids),
        "rationale": result.rationale,
        "provenance_document_id": result.provenance_document_id,
        "metadata": dict(result.metadata),
    }


def deserialize_detection_result_from_checkpoint(data: dict[str, Any]) -> TopicDetectionResult:
    """Ricostruisce un TopicDetectionResult da checkpoint."""
    t_data = data["topic"]
    topic = TopicQuery(
        topic_id=t_data["topic_id"],
        label=t_data["label"],
        description=t_data.get("description", ""),
        is_label_only=t_data.get("is_label_only", False),
    )
    return TopicDetectionResult(
        topic=topic,
        decision=TopicDecision(data["decision"]),
        evidence_ids=tuple(data.get("evidence_ids", ())),
        rationale=data.get("rationale", ""),
        provenance_document_id=data.get("provenance_document_id", ""),
        metadata=dict(data.get("metadata", {})),
    )


def serialize_discovery_result_for_checkpoint(result: TopicDiscoveryResult) -> dict[str, Any]:
    """Serializza deterministicamente un TopicDiscoveryResult validato."""
    return {
        "topics": [
            {
                "label": t.label,
                "short_description": t.short_description,
                "evidence_ids": list(t.evidence_ids),
            }
            for t in result.topics
        ],
        "provenance_document_id": result.provenance_document_id,
        "metadata": dict(result.metadata),
    }


def deserialize_discovery_result_from_checkpoint(data: dict[str, Any]) -> TopicDiscoveryResult:
    """Ricostruisce un TopicDiscoveryResult da checkpoint."""
    topics = [
        DiscoveredTopic(
            label=t["label"],
            short_description=t.get("short_description", ""),
            evidence_ids=tuple(t.get("evidence_ids", ())),
        )
        for t in data.get("topics", ())
    ]
    return TopicDiscoveryResult(
        topics=tuple(topics),
        provenance_document_id=data.get("provenance_document_id", ""),
        metadata=dict(data.get("metadata", {})),
    )


class AnalysisCheckpointStore:
    """
    Gestore thread-safe e atomico del ciclo di vita dei checkpoint forensi su filesystem locale.
    """

    def __init__(self, checkpoint_dir: str | Path | None = None) -> None:
        if checkpoint_dir is None:
            self.checkpoint_dir = Path(".checkpoints")
        else:
            self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    def _get_checkpoint_path(self, document_fingerprint: str, config_fingerprint: str) -> Path:
        safe_name = f"chk_{document_fingerprint[:16]}_{config_fingerprint[:16]}.json"
        return self.checkpoint_dir / safe_name

    def has_checkpoint(self, document_fingerprint: str, config_fingerprint: str) -> bool:
        """Verifica la presenza di un checkpoint esistente su disco."""
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        return p.is_file() and p.stat().st_size > 0

    def load_checkpoint(
        self,
        document_fingerprint: str,
        config_fingerprint: str,
    ) -> AnalysisCheckpoint | None:
        """
        Carica e valida strutturalmente il checkpoint salvato per (document, config).
        Se il file è corrotto o non leggibile, restituisce None senza sollevare eccezioni.
        """
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        if not p.is_file():
            return None
        try:
            with open(p, "r", encoding="utf-8") as f:
                data = json.load(f)
            # Validazione fingerprint di sicurezza
            if data.get("document_fingerprint") != document_fingerprint:
                return None
            if data.get("config_fingerprint") != config_fingerprint:
                return None

            return AnalysisCheckpoint(
                document_id=str(data.get("document_id", "")),
                document_fingerprint=str(data["document_fingerprint"]),
                config_fingerprint=str(data["config_fingerprint"]),
                analysis_type=str(data.get("analysis_type", "")),
                model_id=str(data.get("model_id", "")),
                prompt_version=str(data.get("prompt_version", "")),
                total_planned_chunks=int(data.get("total_planned_chunks", 0)),
                completed_chunk_indices=tuple(sorted(int(x) for x in data.get("completed_chunk_indices", ()))),
                serialized_results=dict(data.get("serialized_results", {})),
                created_at=str(data.get("created_at", "")),
                updated_at=str(data.get("updated_at", "")),
            )
        except Exception:
            return None

    def save_chunk(
        self,
        document_id: str,
        document_fingerprint: str,
        config_fingerprint: str,
        chunk_idx: int,
        result: TopicDetectionResult | TopicDiscoveryResult,
        total_planned_chunks: int,
        analysis_type: str,
        model_id: str,
        prompt_version: str,
    ) -> None:
        """
        Salva atomicamente il risultato validato di un chunk nel checkpoint.
        Scrive su file temporaneo e sostituisce atomicamente per garantire integrità forense.
        """
        existing = self.load_checkpoint(document_fingerprint, config_fingerprint)
        now_iso = datetime.now(timezone.utc).isoformat()
        if existing is not None:
            completed_indices = set(existing.completed_chunk_indices)
            completed_indices.add(chunk_idx)
            results_dict = dict(existing.serialized_results)
            created_at = existing.created_at
        else:
            completed_indices = {chunk_idx}
            results_dict = {}
            created_at = now_iso

        # Serializzazione conforme al tipo
        if isinstance(result, TopicDetectionResult):
            serialized_chunk = serialize_detection_result_for_checkpoint(result)
        elif isinstance(result, TopicDiscoveryResult):
            serialized_chunk = serialize_discovery_result_for_checkpoint(result)
        else:
            raise TypeError(f"Tipo risultato non supportato per checkpoint: {type(result)}")

        results_dict[str(chunk_idx)] = serialized_chunk

        payload = {
            "document_id": document_id,
            "document_fingerprint": document_fingerprint,
            "config_fingerprint": config_fingerprint,
            "analysis_type": analysis_type,
            "model_id": model_id,
            "prompt_version": prompt_version,
            "total_planned_chunks": total_planned_chunks,
            "completed_chunk_indices": sorted(list(completed_indices)),
            "serialized_results": results_dict,
            "created_at": created_at,
            "updated_at": now_iso,
        }

        # Scrittura atomica
        target_path = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        tmp_fd, tmp_path = tempfile.mkstemp(dir=str(self.checkpoint_dir), prefix="chk_tmp_", suffix=".tmp")
        try:
            with open(tmp_fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, target_path)
        except Exception:
            if os.path.exists(tmp_path):
                try:
                    os.remove(tmp_path)
                except OSError:
                    pass
            raise

    def clear_checkpoint(self, document_fingerprint: str, config_fingerprint: str) -> bool:
        """Elimina il checkpoint una volta conclusa con successo l'analisi complessiva."""
        p = self._get_checkpoint_path(document_fingerprint, config_fingerprint)
        if p.is_file():
            try:
                p.unlink()
                return True
            except OSError:
                return False
        return False
