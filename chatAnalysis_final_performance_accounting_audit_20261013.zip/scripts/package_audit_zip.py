import hashlib
import os
import zipfile

ZIP_NAME = "chatAnalysis_integrated_scalability_progress_http400_audit_20261013.zip"

EXCLUDE_DIRS = {
    ".git",
    ".venv",
    ".pytest_cache",
    "__pycache__",
    ".mypy_cache",
    ".ruff_cache",
    ".idea",
    ".vscode",
    "build",
}

EXCLUDE_EXTENSIONS = {
    ".pyc",
    ".pyo",
    ".pyd",
}

EXCLUDE_FILES = {
    ZIP_NAME,
    "chatAnalysis_realworld_topic_analysis_improvements_20261013.zip",
    "git_diff_topic_improvements.patch",  # previous patch
    "REALWORLD_TOPIC_ANALYSIS_IMPROVEMENTS_REPORT.md",  # previous report
}

INCLUDE_ROOT_FILES = [
    "pyproject.toml",
    "README.md",
    "app.py",
    "run_benchmark.sh",
    "benchmark_frozen_sha256.txt",
    "pytest_and_apptest.log",
    "git_diff_integrated_audit.patch",
    "CHATANALYSIS_INTEGRATED_CORRECTIONS_AUDIT_REPORT.md",
    "GIT_BASELINE_AND_STATUS.md",
]

INCLUDE_DIRS = [
    "ai",
    "analysis",
    "core",
    "entity_resolution",
    "importer",
    "multimodal",
    "normalization",
    "profiler",
    "search",
    "ui",
    "unified",
    "validation",
    "tests",
    "test_data",
    "docs",
    "scripts",
    "dist",
]

def sha256_of_file(filepath: str) -> str:
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()

def collect_files():
    file_list = []
    
    # Root files
    for rf in INCLUDE_ROOT_FILES:
        if os.path.isfile(rf):
            file_list.append(rf)
            
    # Directory trees
    for d in INCLUDE_DIRS:
        if not os.path.isdir(d):
            continue
        for root, dirs, files in os.walk(d):
            dirs[:] = [sub for sub in dirs if sub not in EXCLUDE_DIRS]
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                if ext in EXCLUDE_EXTENSIONS:
                    continue
                if file in EXCLUDE_FILES:
                    continue
                # Never include large binary model weights or real databases
                if ext in {".gguf", ".bin", ".onnx", ".db", ".sqlite"} and "test" not in root:
                    continue
                full_path = os.path.join(root, file)
                rel_path = os.path.relpath(full_path, ".").replace("\\", "/")
                file_list.append(rel_path)
                
    return sorted(list(set(file_list)))

def main():
    files = collect_files()
    print(f"Collected {len(files)} files to package.")
    
    manifest_lines = []
    for fpath in files:
        h = sha256_of_file(fpath)
        manifest_lines.append(f"{h}  {fpath}\n")
        
    with open("MANIFEST_SHA256.txt", "w", encoding="utf-8") as mf:
        mf.writelines(manifest_lines)
    print(f"Generated MANIFEST_SHA256.txt with {len(manifest_lines)} entries.")
    
    files.append("MANIFEST_SHA256.txt")
    
    print(f"Writing {ZIP_NAME}...")
    with zipfile.ZipFile(ZIP_NAME, "w", zipfile.ZIP_DEFLATED) as zf:
        for fpath in files:
            zf.write(fpath, arcname=fpath)
            
    zip_size = os.path.getsize(ZIP_NAME)
    zip_hash = sha256_of_file(ZIP_NAME)
    print(f"Success! Created {ZIP_NAME}:")
    print(f"  Size: {zip_size:,} bytes")
    print(f"  SHA256: {zip_hash}")

if __name__ == "__main__":
    main()
