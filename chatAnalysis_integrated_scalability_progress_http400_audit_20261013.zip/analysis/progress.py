"""
analysis/progress.py
--------------------
Sistema di monitoraggio e tracciamento in tempo reale dell'avanzamento per Topic Detection
e Topic Discovery, disaccoppiato da qualsiasi framework UI.

Principi architetturali:
1. DISACCOPPIAMENTO TOTALE DALLA UI:
   Il service layer emette eventi tipizzati AnalysisProgressEvent; la UI Streamlit
   o un client CLI/API implementano il callback senza alcuna dipendenza inversa.
2. CONTEGGI REALI E ACCURATI:
   Distingue con precisione chunk previsti, chunk completati, chunk correnti, chunk rimanenti,
   richieste inviate, richieste riuscite, retry ed errori.
   La percentuale non raggiunge il 100% prima della conclusione di tutte le fasi (incluso il consolidamento).
3. NESSUN POLLING O TIMER FITTIZIO:
   Gli aggiornamenti avvengono esclusivamente a fronte di eventi reali (inizio/fine chunk, retry, errori).
"""
from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import Any, Callable, Mapping


@dataclass(frozen=True)
class AnalysisProgressEvent:
    """
    Evento immutabile di avanzamento dell'analisi tematica.
    """
    phase: str
    total_chunks: int
    completed_chunks: int
    current_chunk_index: int
    remaining_chunks: int
    requests_sent: int
    requests_successful: int
    retries_count: int
    requests_failed: int
    elapsed_seconds: float
    status_message: str
    percentage: float = 0.0
    is_complete: bool = False
    is_failed: bool = False
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def elapsed_formatted(self) -> str:
        """Restituisce il tempo trascorso nel formato HH:MM:SS."""
        total_sec = int(self.elapsed_seconds)
        hours = total_sec // 3600
        minutes = (total_sec % 3600) // 60
        seconds = total_sec % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "total_chunks": self.total_chunks,
            "completed_chunks": self.completed_chunks,
            "current_chunk_index": self.current_chunk_index,
            "remaining_chunks": self.remaining_chunks,
            "requests_sent": self.requests_sent,
            "requests_successful": self.requests_successful,
            "retries_count": self.retries_count,
            "requests_failed": self.requests_failed,
            "elapsed_seconds": self.elapsed_seconds,
            "elapsed_formatted": self.elapsed_formatted,
            "status_message": self.status_message,
            "percentage": self.percentage,
            "is_complete": self.is_complete,
            "is_failed": self.is_failed,
            "metadata": dict(self.metadata),
        }


AnalysisProgressCallback = Callable[[AnalysisProgressEvent], None]


class AnalysisProgressTracker:
    """
    Tracciatore di stato thread-safe per raccogliere e propagare eventi di avanzamento.
    """

    def __init__(
        self,
        total_chunks: int,
        callback: AnalysisProgressCallback | None = None,
        initial_phase: str = "Inizializzazione",
    ) -> None:
        self.total_chunks = max(1, total_chunks)
        self.callback = callback
        self.phase = initial_phase
        self.completed_chunks = 0
        self.current_chunk_index = 0
        self.requests_sent = 0
        self.requests_successful = 0
        self.retries_count = 0
        self.requests_failed = 0
        self.start_time = time.perf_counter()
        self.is_complete = False
        self.is_failed = False
        self._lock = threading.Lock()

    def _calc_percentage(self, complete: bool = False) -> float:
        if complete:
            return 100.0
        if self.total_chunks <= 0:
            return 0.0
        # Cappa al 95% finché la fase di consolidamento non è terminata
        raw = (self.completed_chunks / self.total_chunks) * 95.0
        return round(min(95.0, max(0.0, raw)), 1)

    def _emit(self, status_msg: str, is_complete: bool = False, is_failed: bool = False, meta: dict[str, Any] | None = None) -> AnalysisProgressEvent:
        elapsed = round(time.perf_counter() - self.start_time, 2)
        remaining = max(0, self.total_chunks - self.completed_chunks)
        pct = 100.0 if is_complete else self._calc_percentage(complete=False)

        event = AnalysisProgressEvent(
            phase=self.phase,
            total_chunks=self.total_chunks,
            completed_chunks=self.completed_chunks,
            current_chunk_index=self.current_chunk_index,
            remaining_chunks=remaining,
            requests_sent=self.requests_sent,
            requests_successful=self.requests_successful,
            retries_count=self.retries_count,
            requests_failed=self.requests_failed,
            elapsed_seconds=elapsed,
            status_message=status_msg,
            percentage=pct,
            is_complete=is_complete,
            is_failed=is_failed,
            metadata=meta or {},
        )
        if self.callback:
            try:
                self.callback(event)
            except Exception:
                # Il callback UI non deve mai far fallire il processing del service layer
                pass
        return event

    def start_chunk(self, chunk_idx_1based: int, phase: str = "Analisi dei messaggi") -> AnalysisProgressEvent:
        with self._lock:
            self.phase = phase
            self.current_chunk_index = chunk_idx_1based
            self.requests_sent += 1
            msg = f"Elaborazione blocco {chunk_idx_1based} di {self.total_chunks}..."
            return self._emit(msg)

    def chunk_success(self, chunk_idx_1based: int) -> AnalysisProgressEvent:
        with self._lock:
            self.completed_chunks += 1
            self.requests_successful += 1
            msg = f"Blocco {chunk_idx_1based} di {self.total_chunks} completato con successo."
            return self._emit(msg)

    def chunk_retry(self, chunk_idx_1based: int, reason: str = "") -> AnalysisProgressEvent:
        with self._lock:
            self.retries_count += 1
            self.requests_sent += 1
            detail = f" ({reason})" if reason else ""
            msg = f"Retry blocco {chunk_idx_1based} di {self.total_chunks}{detail}..."
            return self._emit(msg)

    def chunk_failed(self, chunk_idx_1based: int, error_msg: str = "") -> AnalysisProgressEvent:
        with self._lock:
            self.requests_failed += 1
            detail = f": {error_msg}" if error_msg else ""
            msg = f"Blocco {chunk_idx_1based} di {self.total_chunks} fallito{detail}."
            return self._emit(msg)

    def start_consolidation(self) -> AnalysisProgressEvent:
        with self._lock:
            self.phase = "Consolidamento topic"
            msg = "Consolidamento dei risultati dei singoli blocchi in corso..."
            return self._emit(msg)

    def complete(self, summary_msg: str = "Analisi completata con successo.") -> AnalysisProgressEvent:
        with self._lock:
            self.phase = "Completato"
            self.is_complete = True
            return self._emit(summary_msg, is_complete=True)

    def fail(self, error_msg: str) -> AnalysisProgressEvent:
        with self._lock:
            self.phase = "Fallito"
            self.is_failed = True
            return self._emit(f"Analisi fallita: {error_msg}", is_failed=True)
