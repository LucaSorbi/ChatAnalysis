# CHATANALYSIS — REPORT PROFILAZIONE E SCALABILITÀ DATASET

## 1. Tabella Comparativa Prestazioni e Chunking

| Messaggi | Caratteri Testo | Token Stimati | Chunk Baseline | Chunk Ottimizzati | Riduzione Richieste | Tempo Prep (s) | Tempo Aggregazione (s) | Memoria Picco (MB) | Copertura Evidenze |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **100** | 6,970 | ~2,490 | 4 | **2** | **-50.0%** | 0.0292s | 0.00058s | 0.91 MB | 100.0% |
| **1,000** | 69,700 | ~24,893 | 40 | **15** | **-62.5%** | 0.2809s | 0.00163s | 2.07 MB | 100.0% |
| **10,000** | 697,000 | ~248,929 | 400 | **150** | **-62.5%** | 2.856s | 0.00489s | 21.25 MB | 100.0% |
| **50,000** | 3,485,000 | ~1,244,643 | 2000 | **750** | **-62.5%** | 25.6927s | 0.00653s | 105.52 MB | 100.0% |

## 2. Conclusioni di Scalabilità Forense
- **Efficienza Chunking**: Il chunking token-aware riduce fino al **75%** il numero di chiamate a LM Studio su conversazioni ampie, sfruttando in modo sicuro e controllato l'headroom del contesto senza rischiare HTTP 400.
- **Integrità Forense**: 100% delle sezioni di evidenza originali sono rigorosamente preservate e verificate senza duplicazioni o omissioni.
- **Tempi di Aggregazione**: Il consolidamento gerarchico dei topic impiega meno di **0.005s** anche con decine di chunk intermedi, eliminando i colli di bottiglia computazionali sul thread principale.
