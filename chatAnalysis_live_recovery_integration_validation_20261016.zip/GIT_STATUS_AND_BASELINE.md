# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-16)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Release di Riferimento**: `chatAnalysis_live_recovery_integration_validation_20261016.zip`
- **Baseline di partenza**: `chatAnalysis_ubuntu_live_chunk_recovery_checkpoint_safety_audit_20261015.zip`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 `git_diff_live_recovery_integration_validation.patch`).

---

## 2. File Modificati Tracciati e Sintesi delle Correzioni

I seguenti file contengono modifiche rispetto alla baseline:

1. `analysis/service.py`:
   - Integrata l'applicazione reale del parametro `retry_failed_only` in `run_topic_discovery()`.
   - Verifica preliminare rigorosa (Fail-Closed): validazione fingerprint documento e configurazione prima di qualsiasi chiamata al modello. Se il checkpoint è assente o incompatibile, solleva `OperationalAnalysisFailedError` senza mascherare la situazione.
   - Invio al modello esclusivamente dei chunk mancanti. Quelli già completati vengono recuperati dal checkpoint senza chiamate LLM.
   - Presentazione del piano di recupero nel tracker.
   - Registrazione granulare di tutti i fallimenti di chunk nella tabella SQLite `checkpoint_chunk_diagnostics`.
   - Implementazione del metodo `load_persisted_discovery_result()` per il ripristino automatico dello stato e della diagnostica dopo riavvio di Streamlit.
   - Eliminazione dei valori presunti: `attempts` tracciato tramite callback reale di retry, `finish_reason` e `http_status` osservati dalle response effettive (o `None` in caso di errore pre-response).

2. `ai/topics.py`:
   - Ricalcolo deterministico del budget token preventivo prima del retry per `AiInvalidEvidenceCitationError`.
   - Strategia Candidata A (Multi-turn con response precedente e prompt correttivo) e Candidata B (Single-turn compatto con direttiva prescrittiva) tramite `calculate_token_budget_plan()`.
   - Riserva token output garantita (minimo 256 token). Rifiuto preventivo con `AnalysisInputTooLargeError` (`CONTEXT_OVERFLOW`) qualora la richiesta non entri nella context window, evitando HTTP 400 da LM Studio.
   - Nessuna correzione euristica arbitraria degli evidence ID.

3. `analysis/checkpoint.py`:
   - Aggiunto `get_latest_checkpoint_metadata_for_document()` per individuare la configurazione più recente associata a un documento.
   - Segnalazione esplicita tramite `CheckpointSaveError` qualora la scrittura diagnostica fallisca.

4. `ui/presentation.py`:
   - Integrazione del ripristino automatico della Topic Discovery persistita da SQLite all'apertura del tab o al riavvio dell'applicazione tramite `load_persisted_discovery_result()`.
   - Visualizzazione della data di esecuzione (timestamp ISO), stato operativo (`PARTIAL` o `SUCCESS`), modello utilizzato, e numero di chunk mancanti.
   - Pulsante interattivo `🔄 Riprova solo i blocchi falliti` con invocazione reale del recupero selettivo.
   - Download dei rapporti diagnostici completi in JSON e CSV privi di dati privati o chat text.

5. `tests/unit/test_ui_manual_topic_detection.py`:
   - Aggiunta fixture `clean_checkpoints` ad esecuzione automatica per garantire l'isolamento perfetto dei test UI dai checkpoint presenti su disco.

6. `tests/unit/test_ubuntu_live_chunk_failure_and_recovery.py`:
   - Suite specialistica estesa a 12 test (tutti superati al 100%):
     - Casi base 15/26 e ripresa da checkpoint.
     - Retry controllato su citazioni errate.
     - Recupero selettivo con transizione a completamento.
     - Test negativi fail-closed su checkpoint assente e incompatibile.
     - Prevenzione context overflow prima della seconda richiesta.
     - Accuratezza metrica reale (attempts, finish_reason, http_status).
     - Persistenza SQLite degli errori HTTP.
     - Ripristino diagnostica da SQLite dopo riavvio Streamlit.

---

## 3. Risultati della Suite di Test

- **Pytest completo**: **1.778 superati**, 1 saltato, 5 esclusi (benchmark congelati), **0 fallimenti** (in `pytest_and_apptest.log`).
- **Suite Live Ubuntu Recovery (`test_ubuntu_live_chunk_failure_and_recovery.py`)**: **12 su 12 superati**.
- **Suite Specialistica Checkpoint (`test_checkpoint_integrity_scalability.py`)**: **33 su 33 superati**.
- **Streamlit AppTest (`test_apptest_flows.py` e `test_ui_manual_topic_detection.py`)**: **7 su 7** e **13 su 13 superati**.
- **Verifica Wheel di Distribuzione**: `whatsapp_forensic_importer-0.1.0-py3-none-any.whl` compilata ed esaminata con successo in ambiente isolato (`test_packaging_release.py`).

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati modificati e i rispettivi hash crittografici SHA-256 corrispondono esattamente:

| File | SHA256 Rilevato | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
