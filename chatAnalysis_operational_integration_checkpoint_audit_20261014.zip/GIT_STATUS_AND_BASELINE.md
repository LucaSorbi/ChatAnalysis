# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-14)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Ultimo commit tracciato**: `6c1dc468c4d2fe94e9fcf0963aa36fc48bc9568b`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 conforme).

---

## 2. File Modificati Tracciati

I seguenti file contengono modifiche rispetto a `HEAD`:

- `ai/__init__.py`: Esportazione componenti operativi token-aware, listener e planner.
- `ai/backend.py`: Gestione unificata errori backend, categorizzazione overflow e token limit.
- `ai/chunking.py`:
  - Algoritmo token-aware con stima metadati evidenze (`estimate_evidence_framing_tokens`).
  - Normalizzazione morfologica italiana (`canonicalize_topic_label`) con preservazione dell'ordine sintattico per evitare fusioni semantiche improprie (es. "Cessione di armi a privati" vs "Cessione di privati ad armi").
  - Deduplicazione morfologica controllata con `semantic_deduplication=False`.
- `ai/lmstudio.py`:
  - Integrazione listener richieste HTTP reale (`request_listener`) per tracciamento granulare del ciclo di vita: `record_request_sent`, `record_http_response_received`, `record_request_success`, `record_http_error`, `record_timeout`, `record_protocol_error`.
  - Diagnostica HTTP 400 e rilevamento risposte JSON troncate (`finish_reason == "length"`).
- `ai/models.py`: Preservazione evidenze, metadati strutturali e provenance immutabile.
- `ai/topics.py`: Topic detector e analyzer operativi con supporto listener e error classification.
- `analysis/models.py`:
  - Introduzione profili operativi espliciti: `PRUDENT` (2500 tok), `BALANCED` (4200 tok), `PERFORMANCE` (5200 tok).
  - Funzione `resolve_operational_profile()` con verifica headroom e fallback automatico.
  - Dataclass immutabile `AnalysisPlan`.
- `analysis/service.py`:
  - Unica funzione di pianificazione deterministica: `create_analysis_plan()`.
  - Supporto attivo a profili operativi e checkpointing abilitato di default.
  - Connessione del tracker alle richieste HTTP reali del client via listener.
  - Recupero incrementale chunk validati con zero richieste LLM ripetute.
  - Report non bloccante degli errori di salvataggio checkpoint.
- `ui/state.py`:
  - Gestione stato sessione per profilo operativo (`KEY_OPERATIONAL_PROFILE`) e store di checkpoint (`KEY_CHECKPOINT_STORE`).
- `ui/application.py`:
  - Factory `get_operational_analysis_service()` abilitata con checkpointing reale (`AnalysisCheckpointStore`) e profilo selezionato.
  - Propagazione del profilo ai flussi di Detection, Discovery e Prova del Nove.
- `ui/presentation.py`:
  - Selettore profili operativi con spiegazione limiti, headroom check e fallback immediato a Prudente.
  - Pulsante per eliminazione controllata dei checkpoint del documento.
  - Visualizzazione avanzamento dettagliato: richieste inviate, riuscite, fallite, retry, in corso, chunk recuperati da checkpoint.
- `tests/unit/test_apptest_flows.py`:
  - Integrazione fixture di pulizia checkpoint temporanei per test isolati.
- `tests/unit/test_packaging_release.py`:
  - Test validazione wheel costruita con packaging isolato.

---

## 3. Nuovi Moduli e File Introdotti

- `analysis/checkpoint.py`:
  - Sistema di checkpoint e ripresa atomico locale, isolato per documento.
  - Fingerprint crittografico SHA-256 completo (timestamp, ordine, evidenze, testi, ID).
  - Hash configurazione rigoroso (modello, istanza, quantizzazione, context, prompt version, seed, parametri).
  - Validazione post-caricamento dell'esistenza di tutti gli evidence ID nel documento.
  - Permessi restrittivi directory (`0o700`) e scrittura atomica via file temporaneo.
- `tests/unit/test_operational_integration_audit.py`:
  - Suite completa di 18 test obbligatori per la verifica dei 7 problemi d'integrazione operativa.
- `tests/unit/test_performance_accounting_audit.py`:
  - Suite di 12 test unitari dedicati alla contabilità matematica, invariante HTTP e consolidamento.
- `docs/UBUNTU_LIVE_CALIBRATION_GUIDE.md`:
  - Guida alla calibrazione e benchmark LIVE con LM Studio su GPU NVIDIA GTX TITAN X.
- `scripts/generate_operational_patch_utf8.py`:
  - Script per generazione patch Git unificata UTF-8 conforme.
- `scripts/package_operational_integration_zip.py`:
  - Script deterministico per packaging archivio release e SHA256 manifest.

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati toccati e i loro hash SHA-256 corrispondono esattamente:

| File | SHA256 Attuale | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
