"""
analysis/progress.py
--------------------
Sistema di monitoraggio e tracciamento in tempo reale dell'avanzamento per Topic Detection
e Topic Discovery, disaccoppiato da qualsiasi framework UI.

Principi architetturali:
1. DISACCOPPIAMENTO TOTALE DALLA UI:
   Il service layer emette eventi tipizzati AnalysisProgressEvent; la UI Streamlit
   o un client CLI/API implementano il callback senza alcuna dipendenza inversa.
2. CONTEGGI REALI E ACCURATI:
   Distingue con precisione:
   - Chunk pianificati (planned_chunks);
   - Chunk aggiuntivi da suddivisione dinamica (subchunks_added);
   - Chunk complessivi effettivi (total_chunks);
   - Chunk completati con successo (completed_chunks);
   - Chunk falliti (failed_chunks);
   - Chunk ancora da elaborare (remaining_chunks);
   - Chiamate HTTP inviate (requests_sent);
   - Chiamate HTTP riuscite (requests_successful);
   - Retry (retries_count);
   - Chiamate HTTP fallite (requests_failed).
3. COERENZA DEGLI STATI COMPLETE / PARTIAL / FAILED:
   - Un chunk fallito e già processato non viene mai contato come ancora in attesa (remaining_chunks = 0).
   - Un'analisi PARTIAL (con chunk falliti o completamento parziale) non viene mai presentata come COMPLETE al 100%.
   - I totali si adattano deterministicamente alle suddivisioni dinamiche (split_chunk).
   - Evita categoricamente valori anomali come 2/1 o numeri negativi.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import threading
import time
from typing import Any, Callable, Mapping


@dataclass(frozen=True)
class AnalysisProgressEvent:
    """
    Evento immutabile di avanzamento dell'analisi tematica.
    """
    phase: str
    total_chunks: int
    completed_chunks: int
    current_chunk_index: int
    remaining_chunks: int
    requests_sent: int
    requests_successful: int
    retries_count: int
    requests_failed: int
    elapsed_seconds: float
    status_message: str
    percentage: float = 0.0
    is_complete: bool = False
    is_failed: bool = False
    is_partial: bool = False
    failed_chunks: int = 0
    planned_chunks: int = 0
    subchunks_added: int = 0
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def elapsed_formatted(self) -> str:
        """Restituisce il tempo trascorso nel formato HH:MM:SS."""
        total_sec = int(self.elapsed_seconds)
        hours = total_sec // 3600
        minutes = (total_sec % 3600) // 60
        seconds = total_sec % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"

    def to_dict(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "total_chunks": self.total_chunks,
            "completed_chunks": self.completed_chunks,
            "current_chunk_index": self.current_chunk_index,
            "remaining_chunks": self.remaining_chunks,
            "requests_sent": self.requests_sent,
            "requests_successful": self.requests_successful,
            "retries_count": self.retries_count,
            "requests_failed": self.requests_failed,
            "elapsed_seconds": self.elapsed_seconds,
            "elapsed_formatted": self.elapsed_formatted,
            "status_message": self.status_message,
            "percentage": self.percentage,
            "is_complete": self.is_complete,
            "is_failed": self.is_failed,
            "is_partial": self.is_partial,
            "failed_chunks": self.failed_chunks,
            "planned_chunks": self.planned_chunks,
            "subchunks_added": self.subchunks_added,
            "metadata": dict(self.metadata),
        }


AnalysisProgressCallback = Callable[[AnalysisProgressEvent], None]


class AnalysisProgressTracker:
    """
    Tracciatore di stato thread-safe per raccogliere e propagare eventi di avanzamento.
    Garantisce metriche affidabili, contatori non negativi e corretta classificazione di completezza.
    """

    def __init__(
        self,
        total_chunks: int,
        callback: AnalysisProgressCallback | None = None,
        initial_phase: str = "Inizializzazione",
    ) -> None:
        self.planned_chunks = max(1, total_chunks)
        self.subchunks_added = 0
        self.total_chunks = self.planned_chunks
        self.callback = callback
        self.phase = initial_phase
        self.completed_chunks = 0
        self.failed_chunks = 0
        self.current_chunk_index = 0
        self.requests_sent = 0
        self.requests_successful = 0
        self.retries_count = 0
        self.requests_failed = 0
        self.start_time = time.perf_counter()
        self.is_complete = False
        self.is_failed = False
        self.is_partial = False
        self._lock = threading.Lock()

    @property
    def remaining_chunks(self) -> int:
        """Restituisce il numero di blocchi non ancora processati (esclude completati e falliti)."""
        return max(0, self.total_chunks - self.completed_chunks - self.failed_chunks)

    def _calc_percentage(self) -> float:
        if self.total_chunks <= 0:
            return 0.0
        # Cappa al 95% finché la fase di consolidamento non è terminata
        raw = (self.completed_chunks / self.total_chunks) * 95.0
        return round(min(95.0, max(0.0, raw)), 1)

    def _emit(
        self,
        status_msg: str,
        is_complete: bool = False,
        is_failed: bool = False,
        is_partial: bool = False,
        meta: dict[str, Any] | None = None,
        override_pct: float | None = None,
    ) -> AnalysisProgressEvent:
        elapsed = round(time.perf_counter() - self.start_time, 2)
        # Un blocco fallito non è più "in attesa": remaining esclude completati e falliti
        remaining = max(0, self.total_chunks - self.completed_chunks - self.failed_chunks)
        if override_pct is not None:
            pct = override_pct
        elif is_complete:
            pct = 100.0
        else:
            pct = self._calc_percentage()

        event = AnalysisProgressEvent(
            phase=self.phase,
            total_chunks=self.total_chunks,
            completed_chunks=self.completed_chunks,
            current_chunk_index=self.current_chunk_index,
            remaining_chunks=remaining,
            requests_sent=self.requests_sent,
            requests_successful=self.requests_successful,
            retries_count=self.retries_count,
            requests_failed=self.requests_failed,
            elapsed_seconds=elapsed,
            status_message=status_msg,
            percentage=pct,
            is_complete=is_complete,
            is_failed=is_failed,
            is_partial=is_partial,
            failed_chunks=self.failed_chunks,
            planned_chunks=self.planned_chunks,
            subchunks_added=self.subchunks_added,
            metadata=meta or {},
        )
        if self.callback:
            try:
                self.callback(event)
            except Exception:
                # Il callback UI non deve mai far fallire il processing del service layer
                pass
        return event

    def split_chunk(self, chunk_idx_1based: int, subchunks_count: int = 2) -> AnalysisProgressEvent:
        """
        Registra la suddivisione dinamica di un chunk oversize in sotto-chunk.
        Aggiorna il totale previsto evitando conteggi scorretti come 2/1.
        """
        with self._lock:
            added = max(0, subchunks_count - 1)
            self.subchunks_added += added
            self.total_chunks += added
            msg = (
                f"Blocco {chunk_idx_1based} suddiviso in {subchunks_count} sotto-blocchi "
                f"(totale blocchi aggiornato: {self.total_chunks})."
            )
            return self._emit(msg)

    def start_chunk(self, chunk_idx_1based: int, phase: str = "Analisi dei messaggi") -> AnalysisProgressEvent:
        with self._lock:
            self.phase = phase
            self.current_chunk_index = chunk_idx_1based
            self.requests_sent += 1
            msg = f"Elaborazione blocco {chunk_idx_1based} di {self.total_chunks}..."
            return self._emit(msg)

    def chunk_success(self, chunk_idx_1based: int) -> AnalysisProgressEvent:
        with self._lock:
            self.completed_chunks = min(self.total_chunks, self.completed_chunks + 1)
            self.requests_successful += 1
            msg = f"Blocco {chunk_idx_1based} di {self.total_chunks} completato con successo."
            return self._emit(msg)

    def chunk_retry(self, chunk_idx_1based: int, reason: str = "") -> AnalysisProgressEvent:
        with self._lock:
            self.retries_count += 1
            self.requests_sent += 1
            detail = f" ({reason})" if reason else ""
            msg = f"Retry blocco {chunk_idx_1based} di {self.total_chunks}{detail}..."
            return self._emit(msg)

    def chunk_failed(self, chunk_idx_1based: int, error_msg: str = "") -> AnalysisProgressEvent:
        with self._lock:
            self.requests_failed += 1
            self.failed_chunks += 1
            detail = f": {error_msg}" if error_msg else ""
            msg = f"Blocco {chunk_idx_1based} di {self.total_chunks} fallito{detail}."
            return self._emit(msg)

    def start_consolidation(self) -> AnalysisProgressEvent:
        with self._lock:
            self.phase = "Consolidamento topic"
            msg = "Consolidamento dei risultati dei singoli blocchi in corso..."
            return self._emit(msg)

    def complete(
        self,
        summary_msg: str = "Analisi completata con successo.",
        is_partial: bool = False,
    ) -> AnalysisProgressEvent:
        """
        Segnala il completamento dell'analisi.
        Se vi sono blocchi falliti o se is_partial è True, l'evento viene emesso come
        PARTIAL e la percentuale rispecchia la copertura reale (non 100%).
        """
        with self._lock:
            # Riconoscimento automatico o esplicito di esecuzione parziale
            should_be_partial = is_partial or self.failed_chunks > 0 or self.completed_chunks < self.total_chunks
            if should_be_partial and self.completed_chunks > 0:
                self.phase = "Completato parzialmente"
                self.is_complete = False
                self.is_partial = True
                self.is_failed = False
                pct = round((self.completed_chunks / self.total_chunks) * 100.0, 1) if self.total_chunks > 0 else 0.0
                return self._emit(summary_msg, is_complete=False, is_failed=False, is_partial=True, override_pct=pct)
            elif should_be_partial and self.completed_chunks == 0:
                # Se tutti sono falliti, non è nemmeno parziale: è fallito
                self.phase = "Fallito"
                self.is_complete = False
                self.is_partial = False
                self.is_failed = True
                return self._emit(summary_msg, is_complete=False, is_failed=True, is_partial=False, override_pct=0.0)
            else:
                self.phase = "Completato"
                self.is_complete = True
                self.is_partial = False
                self.is_failed = False
                return self._emit(summary_msg, is_complete=True, is_failed=False, is_partial=False, override_pct=100.0)

    def partial(self, summary_msg: str = "Analisi completata parzialmente.") -> AnalysisProgressEvent:
        """Segnala esplicitamente un completamento parziale (PARTIAL)."""
        return self.complete(summary_msg=summary_msg, is_partial=True)

    def fail(self, error_msg: str) -> AnalysisProgressEvent:
        with self._lock:
            self.phase = "Fallito"
            self.is_failed = True
            self.is_complete = False
            self.is_partial = False
            pct = round((self.completed_chunks / self.total_chunks) * 100.0, 1) if self.total_chunks > 0 else 0.0
            return self._emit(f"Analisi fallita: {error_msg}", is_complete=False, is_failed=True, is_partial=False, override_pct=pct)
