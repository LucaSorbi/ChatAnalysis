# CHATANALYSIS — REPORT PROFILAZIONE E SCALABILITÀ DATASET (POST-AUDIT)

## 1. Tabella Comparativa Prestazioni e Chunking Operativo

La tabella confronta la configurazione **Baseline** (7.500 caratteri, 25 bundle, senza limite token) con la configurazione **Ottimizzata Token-Aware** (12.000 caratteri, 100 bundle, budget token calcolato dinamicamente a 2.500 token) applicata direttamente su `LocalTopicAnalysisService`.

| Messaggi | Caratteri Testo | Token Stimati | Chunk Baseline (7.5k/25) | Chunk Ottimizzati (12k/100/2.5k) | Riduzione Richieste | Tempo Prep (s) | Tempo Aggregazione (s) | Memoria Picco (MB) | Copertura Evidenze |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **100** | 6,970 | ~2,490 | 4 | **5** | **--25.0%** | 0.0314s | 0.0008s | 0.24 MB | 100.0% |
| **1,000** | 69,700 | ~24,893 | 40 | **46** | **--15.0%** | 0.3141s | 0.00447s | 2.09 MB | 100.0% |
| **10,000** | 697,000 | ~248,929 | 400 | **455** | **--13.8%** | 3.1678s | 0.00522s | 21.41 MB | 100.0% |
| **50,000** | 3,485,000 | ~1,244,643 | 2000 | **2273** | **--13.7%** | 27.9656s | 0.0052s | 106.28 MB | 100.0% |

## 2. Conclusioni di Scalabilità e Sicurezza Forense
- **Sicurezza del Contesto LLM e Prevenzione HTTP 400**: La configurazione Baseline storica (25 bundle fissi / 7.500 caratteri) non teneva conto dell'overhead di serializzazione JSON delle evidenze (~85 token per evidenza) né del prompt e dello schema, rischiando overflow di contesto su messaggi densi. Il chunking token-aware limita rigorosamente la dimensione di ciascun blocco a un budget compatibile con la context window (8.192 token), prevenendo sistematicamente errori HTTP 400.
- **Integrità Forense delle Evidenze**: Il 100% delle sezioni di evidenza e dei messaggi è rigorosamente preservato (nessun evidence ID omesso o alterato).
- **Verifica sul Percorso Operativo Reale**: La funzione `run_topic_discovery()` di `LocalTopicAnalysisService` è stata eseguita end-to-end verificando la perfetta corrispondenza tra chunk pianificati (5 chunk su 100 messaggi), esito `COMPLETE` e metadati forensi.
- **Memoria e Tempi di Consolidamento**: L'aggregazione multi-chunk gerarchica impiega circa 0.005s per consolidare i topic e la memoria di picco rimane perfettamente contenuta (~106 MB anche a 50.000 messaggi).
