"""
tests/unit/test_media_registry_session_isolation.py
----------------------------------------------------
Test di regressione e audit forense per BLOCKER 1:
- Session A registra un file, Session B non lo vede.
- Session A e B importano documenti con document_id identico: nessuna contaminazione.
- Reset A cancella soltanto risorse di A.
- Reset B non modifica le risorse di A.
- File temporanei realmente eliminati dopo cleanup.
- Nessun accesso tramite registri globali o class methods (_fallback_default e _HybridRegistryMethod rimossi).
- Multi-conversation A -> B -> A nella stessa sessione continua a funzionare.
- L'ingestion ZIP conserva l'accesso autorizzato ai media dopo il cleanup dello staging.
"""
from __future__ import annotations

import os
from pathlib import Path
import tempfile
import zipfile
import pytest

from multimodal.asset_access import (
    MediaAssetRegistry,
    MediaAssetAccessService,
    MediaSourceUnavailableError,
)
from ui import state
from ui.ingestion import ingest_file_payload
from ui.models import IngestionRequest, SourceFormat


def test_session_a_registers_file_session_b_cannot_see_it(tmp_path: Path):
    """Session A registra un file, Session B non lo vede."""
    file_a = tmp_path / "chat_a.zip"
    file_a.write_bytes(b"PK\x05\x06" + b"\x00" * 18)

    reg_a = MediaAssetRegistry(document_id="doc_123")
    reg_b = MediaAssetRegistry(document_id="doc_123")

    reg_a.register_archive("doc_123", file_a)

    assert reg_a.get_archive("doc_123") == file_a
    assert reg_b.get_archive("doc_123") is None


def test_identical_document_ids_in_separate_sessions_no_contamination(tmp_path: Path):
    """Session A e B importano documenti con document_id identico: nessuna contaminazione."""
    file_a = tmp_path / "archive_session_a.zip"
    file_b = tmp_path / "archive_session_b.zip"
    file_a.write_bytes(b"PK\x05\x06" + b"\x00" * 18)
    file_b.write_bytes(b"PK\x05\x06" + b"\x00" * 18)

    session_state_a: dict = {}
    session_state_b: dict = {}

    state.init_session_state(session_state_a)
    state.init_session_state(session_state_b)

    reg_a = state.get_media_asset_registry("shared_doc_id", state=session_state_a)
    reg_b = state.get_media_asset_registry("shared_doc_id", state=session_state_b)

    reg_a.register_archive("shared_doc_id", file_a)
    reg_b.register_archive("shared_doc_id", file_b)

    assert reg_a.get_archive("shared_doc_id") == file_a
    assert reg_b.get_archive("shared_doc_id") == file_b
    assert reg_a.get_archive("shared_doc_id") != reg_b.get_archive("shared_doc_id")


def test_reset_a_only_clears_a_resources(tmp_path: Path):
    """Reset A cancella soltanto le risorse di A; Reset B non modifica le risorse di A."""
    file_a = tmp_path / "file_a.zip"
    file_b = tmp_path / "file_b.zip"
    file_a.write_bytes(b"PK\x05\x06" + b"\x00" * 18)
    file_b.write_bytes(b"PK\x05\x06" + b"\x00" * 18)

    session_a: dict = {}
    session_b: dict = {}
    state.init_session_state(session_a)
    state.init_session_state(session_b)

    reg_a = state.get_media_asset_registry("doc_a", state=session_a)
    reg_b = state.get_media_asset_registry("doc_b", state=session_b)

    reg_a.register_archive("doc_a", file_a)
    reg_b.register_archive("doc_b", file_b)

    # Reset A
    state.reset_dataset(state=session_a)

    assert reg_a.get_archive("doc_a") is None
    # Risorse di B rimangono intatte
    assert reg_b.get_archive("doc_b") == file_b

    # Reset B
    state.reset_dataset(state=session_b)
    assert reg_b.get_archive("doc_b") is None


def test_temp_files_actually_deleted_after_cleanup():
    """File temporanei e cartelle realmente eliminati dopo cleanup del registry."""
    reg = MediaAssetRegistry(document_id="doc_cleanup")
    managed_dir = reg.managed_temp_dir
    assert managed_dir.exists()

    # Crea file gestito nel registry
    temp_file = managed_dir / "test_artifact.bin"
    temp_file.write_bytes(b"temporary forensic payload")
    assert temp_file.exists()

    # Esegui cleanup
    reg.clear()

    # Verifica rimozione fisica
    assert not temp_file.exists()
    assert not managed_dir.exists()


def test_no_global_registry_or_class_methods():
    """Nessun accesso consentito tramite registri globali o class methods su MediaAssetRegistry."""
    # Verifica che _fallback_default non esista
    assert not hasattr(MediaAssetRegistry, "_fallback_default")
    assert not hasattr(MediaAssetRegistry, "_HybridRegistryMethod")

    # Invocazione di metodi come class method deve fallire o richiedere istanza
    with pytest.raises(TypeError):
        MediaAssetRegistry.register_archive("doc_x", Path("some/path"))  # type: ignore

    with pytest.raises(TypeError):
        MediaAssetRegistry.get_archive("doc_x")  # type: ignore


def test_multi_conversation_a_to_b_to_a_in_same_session(tmp_path: Path):
    """Multi-conversation A -> B -> A nella stessa sessione continua a funzionare con isolamento."""
    session: dict = {}
    state.init_session_state(session)

    file_a = tmp_path / "chat_alpha.zip"
    file_b = tmp_path / "chat_beta.zip"
    file_a.write_bytes(b"PK\x05\x06" + b"\x00" * 18)
    file_b.write_bytes(b"PK\x05\x06" + b"\x00" * 18)

    reg_a = state.get_media_asset_registry("chat_alpha", state=session)
    reg_b = state.get_media_asset_registry("chat_beta", state=session)

    reg_a.register_archive("chat_alpha", file_a)
    reg_b.register_archive("chat_beta", file_b)

    # Selezione Alpha -> Beta -> Alpha
    assert state.get_media_asset_registry("chat_alpha", state=session).get_archive("chat_alpha") == file_a
    assert state.get_media_asset_registry("chat_beta", state=session).get_archive("chat_beta") == file_b
    assert state.get_media_asset_registry("chat_alpha", state=session).get_archive("chat_alpha") == file_a


def test_zip_ingestion_preserves_authorized_media_access_after_staging_cleanup(tmp_path: Path):
    """L'ingestion ZIP conserva l'accesso autorizzato ai media dopo il cleanup dello staging."""
    zip_bytes_io = tempfile.NamedTemporaryFile(suffix=".zip", delete=False)
    zip_path = Path(zip_bytes_io.name)
    zip_bytes_io.close()

    try:
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("_chat.txt", "10/05/2024, 10:00 - Alice: Guarda questa foto: photo.jpg\n".encode("utf-8"))
            zf.writestr("photo.jpg", b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01_test_jpg")

        payload = zip_path.read_bytes()
    finally:
        if zip_path.exists():
            zip_path.unlink()

    session_reg = MediaAssetRegistry(document_id="session_reg_test")
    res = ingest_file_payload(
        IngestionRequest(
            source_format=SourceFormat.WHATSAPP_EXPORT,
            filename="chat_export.zip",
            file_bytes=payload,
        ),
        media_registry=session_reg,
    )

    doc = next(iter(res.documents.values()))
    archive_path = session_reg.get_archive(doc.document_id)
    assert archive_path is not None
    assert archive_path.exists()

    # Il service media con il registry esplicito accede al membro
    service = MediaAssetAccessService(archive_path=archive_path, registry=session_reg)
    with service.materialize_member("photo.jpg") as photo_path:
        assert photo_path.exists()
        assert b"JFIF" in photo_path.read_bytes()

    # Pulizia
    session_reg.clear()
    assert not archive_path.exists()
