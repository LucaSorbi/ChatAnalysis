# Benchmark Sperimentale AI Locale — Topic Detection Multilingue

**Modello**: `synthetic_reference_evaluator`  
**Data**: 2026-09-11  
**Avviso**: Campione sperimentale pilota non generalizzabile statisticamente.  

## 1. Metriche per Strategia Linguistica

| Strategia | Query Totali | Accuracy | Precision | Recall | F1 Score | Incerti | Fallimenti Output | Latenza Media (s) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **DIRECT_MULTILINGUAL** | 8 | 0.75 | 1.0 | 1.0 | 1.0 | 0 | 2 | 0.0 |
| **TRANSLATE_FIRST** | 8 | 0.75 | 1.0 | 1.0 | 1.0 | 0 | 2 | 0.0 |

## 2. Note Metodologiche
- Dataset pilota non sensibile costituito da conversazioni sintetiche in IT, EN, ES e lingua mista.
- Le citazioni di evidenza mantengono la provenienza deterministica.