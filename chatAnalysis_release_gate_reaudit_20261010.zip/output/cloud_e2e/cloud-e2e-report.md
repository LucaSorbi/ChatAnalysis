# Preliminary Cloud E2E Benchmark Report — Synthetic Dataset

> **Tipo Benchmark:** TECHNICAL VALIDATION BENCHMARK
> **Disclaimer Scientifico:** Questo benchmark sintetico è uno strumento di validazione tecnica E2E preliminare su 6 casi controllati. Non costituisce una valutazione statistica generale del modello.

## 1. Configurazione dell'Esperimento

- **Timestamp UTC:** `2026-10-03T11:02:20.892415+00:00`
- **Endpoint:** `https://generativelanguage.googleapis.com/v1beta/openai`
- **Modello Richiesto:** `gemini-3.8-flash`
- **Modalità JSON:** `json_schema`
- **Timeout:** `120.0s` | **Max Tokens:** `1024`
- **Temperature:** `0.0` | **Seed:** `42`
- **Dataset SHA-256:** `2E49A9C62D89125D...` (VERIFICATO)
- **Ground Truth SHA-256:** `377FB95B7690BA50...` (VERIFICATO)

## 2. Metriche Sintetiche di Topic Detection

| Metrica | Valore |
|---------|--------|
| Casi Totali Valutati | 6 |
| Casi Completati con Successo | 0 |
| Casi Falliti | 6 |
| Decisioni Corrette | 0 / 6 |
| Accuratezza Decisionale | 0.0% |
| PRESENT (Corretti/Totale) | 0 / 4 |
| ABSENT (Corretti/Totale) | 0 / 1 |
| UNCERTAIN (Corretti/Totale) | 0 / 1 |
| Citazioni Evidenze Invalide | 0 |
| Errori Structured Output | 0 |
| Errori Backend / Rete | 6 |
| Errori Model Mismatch | 0 |
| Latenza Media Inferenza Riuscita | 0.0s |

## 3. Dettaglio Risultati per Caso

| Caso | Strategia | Atteso | Ottenuto | Esito | Latenza | Token Totali | Status |
|------|-----------|--------|----------|-------|---------|--------------|--------|
| CASE_1_EXPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_2_IMPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_3_AMBIGUOUS_UNCERTAIN | DIRECT_MULTILINGUAL | UNCERTAIN | - | FAILED | N/A | N/A | FAILED |
| CASE_4_ABSENT | DIRECT_MULTILINGUAL | ABSENT | - | FAILED | N/A | N/A | FAILED |
| CASE_5_MULTILINGUAL_DIRECT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_5_MULTILINGUAL_TRANSLATE_FIRST | TRANSLATE_FIRST | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_6_TOPIC_DISCOVERY | DIRECT_MULTILINGUAL | Discovery | 0 topics scoperti | QUALITATIVE | N/A | N/A | FAILED |

## 4. Dettaglio Topic Discovery (Caso 6 — Valutazione Qualitativa Post-Hoc)

Topic Discovery non riuscito. Errore: `AiBackendRequestError` — `Errore HTTP 400 dall'endpoint cloud (https://generativelanguage.googleapis.com/v1beta/openai): Bad Request. Risposta: [{
  "error": {
    "code": 400,
    "message": "Invalid JSON payload received. Unknown name \"seed\": Cannot find field.",
    "status": "INVALID_ARGUMENT",
    "details": [
      {
        "@type": "type.googleapis.com/google.rpc.BadRequest",
     `

---
**Dichiarazioni di Sicurezza:**
- Nessun dato reale o personale è stato elaborato (SYNTHETIC DATA ONLY).
- Nessuna API key o credenziale è stata salvata in chiaro nei report.
- Il percorso finale della tesi rimane su hardware locale (LM Studio + Qwen/Llama/DeepSeek).