# Preliminary Cloud E2E Benchmark Report — Synthetic Dataset (Protocol V2)

> **Tipo Benchmark:** TECHNICAL VALIDATION BENCHMARK
> **Protocol Version:** 2
> **Disclaimer Scientifico:** Questo benchmark sintetico è uno strumento di validazione tecnica E2E preliminare su 6 casi controllati. Non costituisce una valutazione statistica generale del modello.

## 1. Configurazione dell'Esperimento

- **Protocol Version:** `2`
- **Timestamp UTC:** `2026-10-03T15:19:05.338428+00:00`
- **Provider:** `Google Gemini Developer API`
- **Endpoint:** `https://generativelanguage.googleapis.com/v1beta/openai`
- **Modello Richiesto:** `gemini-3.8-flash`
- **Modello Restituito:** `gemini-3.8-flash`
- **Modalità JSON:** `json_schema`
- **Timeout:** `120.0s` | **Max Tokens:** `1024`
- **Temperature:** `0.0` | **Seed:** `null` (UNSUPPORTED_OMITTED)
- **Dataset SHA-256:** `2E49A9C62D89125D...` (VERIFICATO)
- **Ground Truth SHA-256:** `377FB95B7690BA50...` (VERIFICATO)

## 2. Metriche di Esecuzione e Topic Detection

### 2.1 Esecuzione Chiamate e Inferenze
- **Cloud API Requests Sent:** 8
- **LLM Inferences Completed:** 3
- **Model Outputs Received:** 3
- **Detection Completion Rate:** 33.3%

### 2.2 Metriche Decisionali

| Metrica | Valore |
|---|---|
| Casi Totali Valutati | 6 |
| Casi Completati con Successo | 2 |
| Casi Falliti (Backend/Execution) | 4 |
| Detection Completion Rate | 33.3% |
| Decisioni Corrette (Casi Completati) | 2 / 2 |
| Accuratezza Decisionale (Casi Completati) | 100.0% |
| PRESENT (Corretti/Completati/Totale) | 1 / 1 (4 totali) |
| ABSENT (Corretti/Completati/Totale) | 1 / 1 (1 totali) |
| UNCERTAIN (Corretti/Completati/Totale) | 0 / 0 (1 totali) |
| Citazioni Evidenze Invalide | 0 |
| Errori Structured Output | 0 |
| Errori Backend / Rete | 4 |
| Errori Model Mismatch | 0 |
| Latenza Media Inferenza Riuscita | 2.913s |

## 3. Dettaglio Risultati per Caso

| Caso | Strategia | Atteso | Ottenuto | Esito | Latenza | Token Totali | Status |
|------|-----------|--------|----------|-------|---------|--------------|--------|
| CASE_1_EXPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | PRESENT | CORRETTO | 3.204s | 1803 | SUCCESS |
| CASE_2_IMPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_3_AMBIGUOUS_UNCERTAIN | DIRECT_MULTILINGUAL | UNCERTAIN | - | FAILED | N/A | N/A | FAILED |
| CASE_4_ABSENT | DIRECT_MULTILINGUAL | ABSENT | ABSENT | CORRETTO | 2.622s | 1755 | SUCCESS |
| CASE_5_MULTILINGUAL_DIRECT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_5_MULTILINGUAL_TRANSLATE_FIRST | TRANSLATE_FIRST | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_6_TOPIC_DISCOVERY | DIRECT_MULTILINGUAL | Discovery | 0 topics scoperti | QUALITATIVE | N/A | N/A | FAILED |

## 4. Dettaglio Topic Discovery (Caso 6 — Valutazione Qualitativa Post-Hoc)

Topic Discovery non riuscito. Errore: `AiBackendRequestError` — `Errore HTTP 429 dall'endpoint cloud (https://generativelanguage.googleapis.com/v1beta/openai): Too Many Requests. Risposta: [{
  "error": {
    "code": 429,
    "message": "You exceeded your current quota, please check your plan and billing details. For more information on this error, head to: https://ai.google.dev/gemini-api/docs/rate-limits. To monitor your current usag`

---
**Dichiarazioni di Sicurezza:**
- Nessun dato reale o personale è stato elaborato (SYNTHETIC DATA ONLY).
- Nessuna API key o credenziale è stata salvata in chiaro nei report.
- Il percorso finale della tesi rimane su hardware locale (LM Studio + Qwen/Llama/DeepSeek).