# Preliminary Cloud E2E Benchmark Report — Synthetic Dataset (Protocol V3)

> **Tipo Benchmark:** TECHNICAL VALIDATION BENCHMARK
> **Protocol Version:** 3
> **Disclaimer Scientifico:** Questo benchmark sintetico è uno strumento di validazione tecnica E2E preliminare su 6 casi controllati. Non costituisce una valutazione statistica generale del modello.

## 1. Configurazione dell'Esperimento

- **Protocol Version:** `3`
- **Timestamp UTC:** `2026-10-04T07:19:59.138923+00:00`
- **Provider:** `Google Gemini Developer API`
- **Endpoint:** `https://generativelanguage.googleapis.com/v1beta/openai`
- **Modello Richiesto:** `gemini-3.8-flash`
- **Modello Restituito:** `gemini-3.8-flash`
- **Modalità JSON:** `json_schema`
- **Timeout:** `120.0s` | **Max Tokens:** `1024`
- **Temperature:** `0.0` | **Seed:** `null` (UNSUPPORTED_OMITTED)
- **Pacing Preventivo (Interval):** `15.0s`
- **Limiti Provider Osservati:** `5 RPM` | `250000 TPM` | `20 RPD`
- **Automatic Retry:** `NO (One request = One attempt)`
- **Dataset SHA-256:** `2E49A9C62D89125D...` (VERIFICATO)
- **Ground Truth SHA-256:** `377FB95B7690BA50...` (VERIFICATO)

## 2. Metriche di Esecuzione e Topic Detection

### 2.1 Esecuzione Chiamate e Inferenze
- **Cloud API Requests Sent:** 8
- **LLM Inferences Completed:** 5
- **Model Outputs Received:** 5
- **Detection Completion Rate:** 50.0%

### 2.2 Pacing Telemetria Preventivo (Protocol V3)
- **Intervallo Minimo Configurato:** `15.0s`
- **Richieste con Pacing:** 8
- **Delta Minimo Osservato Inizio Richieste:** 15.0s
- **Delta Medio Osservato Inizio Richieste:** 15.001s
- **Policy di Retry:** `NESSUNA (Automatic Retry: False, Selective Retry: False)`

| Seq | Offset Inizio (s) | Delta da Richiesta Precedente (s) |
|---|---|---|
| 1 | 0.000s | N/A (prima richiesta) |
| 2 | 15.001s | 15.001s |
| 3 | 30.002s | 15.001s |
| 4 | 45.003s | 15.001s |
| 5 | 60.005s | 15.002s |
| 6 | 75.005s | 15.000s |
| 7 | 90.006s | 15.001s |
| 8 | 105.006s | 15.001s |

### 2.3 Metriche Decisionali

| Metrica | Valore |
|---|---|
| Casi Totali Valutati | 6 |
| Casi Completati con Successo | 3 |
| Casi Falliti (Backend/Execution) | 3 |
| Detection Completion Rate | 50.0% |
| Decisioni Corrette (Casi Completati) | 2 / 3 |
| Accuratezza Decisionale (Casi Completati) | 66.7% |
| PRESENT (Corretti/Completati/Totale) | 1 / 1 (4 totali) |
| ABSENT (Corretti/Completati/Totale) | 1 / 1 (1 totali) |
| UNCERTAIN (Corretti/Completati/Totale) | 0 / 1 (1 totali) |
| Citazioni Evidenze Invalide | 0 |
| Errori Structured Output | 0 |
| Errori Backend / Rete | 3 |
| Errori Model Mismatch | 0 |
| Latenza Media Inferenza Riuscita | 4.78s |

## 3. Dettaglio Risultati per Caso

| Caso | Strategia | Atteso | Ottenuto | Esito | Latenza | Token Totali | Status |
|------|-----------|--------|----------|-------|---------|--------------|--------|
| CASE_1_EXPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | PRESENT | CORRETTO | 3.318s | 1815 | SUCCESS |
| CASE_2_IMPLICIT_PRESENT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_3_AMBIGUOUS_UNCERTAIN | DIRECT_MULTILINGUAL | UNCERTAIN | PRESENT | ERRATO | 4.752s | 1981 | SUCCESS |
| CASE_4_ABSENT | DIRECT_MULTILINGUAL | ABSENT | ABSENT | CORRETTO | 6.27s | 1512 | SUCCESS |
| CASE_5_MULTILINGUAL_DIRECT | DIRECT_MULTILINGUAL | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_5_MULTILINGUAL_TRANSLATE_FIRST | TRANSLATE_FIRST | PRESENT | - | FAILED | N/A | N/A | FAILED |
| CASE_6_TOPIC_DISCOVERY | DIRECT_MULTILINGUAL | Discovery | 6 topics scoperti | QUALITATIVE | 3.872s | 2412 | SUCCESS |

## 4. Dettaglio Topic Discovery (Caso 6 — Valutazione Qualitativa Post-Hoc)

### Topic Estratti Autonomamente dal Modello:
1. **Riunione condominiale**: Comunicazione dello spostamento della riunione di condominio a giovedì con dettagli sull'ordine del giorno. (Evidenze: `['unified:cellebrite_json:ce2e_c6_001::ORIGINAL_TEXT']`)
2. **Partita di calcetto**: Organizzazione e invito a partecipare a una partita di calcetto prevista per sabato. (Evidenze: `['unified:cellebrite_json:ce2e_c6_002::ORIGINAL_TEXT']`)
3. **Cena al ristorante giapponese**: Pianificazione di una cena domenicale a base di sushi e ramen in centro. (Evidenze: `['unified:cellebrite_json:ce2e_c6_003::ORIGINAL_TEXT']`)
4. **Acquisto di un romanzo**: Accordo per una sosta in libreria prima di cena per l'acquisto di un libro giallo. (Evidenze: `['unified:cellebrite_json:ce2e_c6_004::ORIGINAL_TEXT']`)
5. **Visita veterinaria e passaggio in auto**: Richiesta e conferma di un passaggio in auto per portare un gatto a fare il vaccino dal veterinario. (Evidenze: `['unified:cellebrite_json:ce2e_c6_005::ORIGINAL_TEXT', 'unified:cellebrite_json:ce2e_c6_006::ORIGINAL_TEXT']`)
6. **Concerto jazz**: Acquisto di due biglietti per un concerto jazz al teatro comunale per il venerdì successivo. (Evidenze: `['unified:cellebrite_json:ce2e_c6_006::ORIGINAL_TEXT']`)

### Topic Attesi Post-Hoc (per confronto qualitativo umano):
1. **Riunione di Condominio** (Keywords: condominio, riunione, amministratore, spese, assemblea)
2. **Calcetto e Attività Sportive** (Keywords: calcetto, partita, giovedì, campo, squadra)
3. **Ristorazione e Cucina** (Keywords: ristorante, sushi, giapponese, cena, prenotare)
4. **Libri e Lettura** (Keywords: libro, romanzo, thriller, libreria, leggere)
5. **Animali Domestici e Cure Veterinarie** (Keywords: cane, veterinario, vaccino, visita, clinica)
6. **Eventi Musicali e Concerti** (Keywords: concerto, jazz, biglietti, festival, musica)

## 5. Criteri di Interpretazione e Distinzione Errori

- **HTTP 429 (Too Many Requests) / HTTP 503 (Service Unavailable):** Classificati come **Execution Failure** dovuti ai vincoli di quota (5 RPM) o disponibilità del provider, **NON** come errori decisionali del modello.
- **Citazioni Evidenze Invalide / Structured Output Error:** Classificati come **Model Format / Compliance Failure**.
- **Decisione Dissonante da Ground Truth:** Classificata come **Model Decision Error**.
- **Nessun Retry:** Ogni richiesta viene eseguita esattamente una volta; fallimenti 429 o 503 non vengono ripetuti.

---
**Dichiarazioni di Sicurezza:**
- Nessun dato reale o personale è stato elaborato (SYNTHETIC DATA ONLY).
- Nessuna API key o credenziale è stata salvata in chiaro nei report.
- Il percorso finale della tesi rimane su hardware locale (LM Studio + Qwen/Llama/DeepSeek).