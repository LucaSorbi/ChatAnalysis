# Forensic Data Profile

**Generated**: 2026-09-09T07:20:20.133171+00:00  
**Profiler version**: 1.0.0  
**Anonymized**: False  
**Sample text included**: True  

> [!CAUTION]
> This report does not contain raw message content. All sender identifiers have been anonymized.

---
## 1. File Structure

| Metric | Value |
|--------|-------|
| Total files | 40 |
| Total size | 211.0 KB |
| Largest file | `whatsapp_export\msgstore.db` (100.0 KB) |

### Files by type

| Type   | Count | % of total |
| ------ | ----- | ---------- |
| audio  | 10    | 25.0%      |
| csv    | 1     | 2.5%       |
| image  | 20    | 50.0%      |
| json   | 1     | 2.5%       |
| sqlite | 2     | 5.0%       |
| video  | 5     | 12.5%      |
| xml    | 1     | 2.5%       |

### Files by extension

| Extension | Count |
| --------- | ----- |
| .jpg      | 20    |
| .opus     | 10    |
| .mp4      | 5     |
| .db       | 2     |
| .csv      | 1     |
| .json     | 1     |
| .xml      | 1     |

---
## 2. SQLite Databases

### `whatsapp_export\msgstore.db` (100.0 KB)
**Tables**: 4 | **Views**: 0 | **Indexes**: 1

#### Table: `chat_list` ⚠️ *likely messages*
**Rows**: 3

| Column                     | Type    | Role    | Null       | Unique        | Avg len    | Timestamp info |
| -------------------------- | ------- | ------- | ---------- | ------------- | ---------- | -------------- |
| _id                        | INTEGER | id      | 0.0% null  | 100.0% unique | avg 1.0ch  |                |
| key_remote_jid             | TEXT    | sender  | 0.0% null  | 100.0% unique | avg 27.7ch |                |
| message_table_id           | INTEGER | unknown | 0.0% null  | 100.0% unique | avg 1.0ch  |                |
| subject                    | TEXT    | unknown | 66.7% null | 100.0% unique | avg 16.0ch |                |
| creation                   | INTEGER | unknown | 0.0% null  | 33.3% unique  | avg 13.0ch |                |
| last_read_message_table_id | INTEGER | unknown | 0.0% null  | 33.3% unique  | avg 1.0ch  |                |
| hidden                     | INTEGER | unknown | 0.0% null  | 33.3% unique  | avg 1.0ch  |                |


#### Table: `media_refs`
**Rows**: 115

| Column         | Type    | Role    | Null      | Unique        | Avg len    | Timestamp info |
| -------------- | ------- | ------- | --------- | ------------- | ---------- | -------------- |
| _id            | INTEGER | id      | 0.0% null | 100.0% unique | avg 2.1ch  |                |
| message_row_id | INTEGER | unknown | 0.0% null | 100.0% unique | avg 2.8ch  |                |
| media_job_uuid | TEXT    | unknown | 0.0% null | 100.0% unique | avg 7.8ch  |                |
| file_path      | TEXT    | media   | 0.0% null | 100.0% unique | avg 28.9ch |                |
| file_size      | INTEGER | unknown | 0.0% null | 100.0% unique | avg 6.8ch  |                |
| media_type     | INTEGER | unknown | 0.0% null | 2.6% unique   | avg 1.0ch  |                |


#### Table: `messages` ⚠️ *likely messages*
**Rows**: 504

| Column                   | Type    | Role      | Null        | Unique        | Avg len    | Timestamp info                    |
| ------------------------ | ------- | --------- | ----------- | ------------- | ---------- | --------------------------------- |
| _id                      | INTEGER | id        | 0.0% null   | 100.0% unique | avg 2.8ch  |                                   |
| key_remote_jid           | TEXT    | sender    | 0.0% null   | 0.6% unique   | avg 27.7ch |                                   |
| key_from_me              | INTEGER | unknown   | 0.0% null   | 0.4% unique   | avg 1.0ch  |                                   |
| key_id                   | TEXT    | unknown   | 0.0% null   | 99.8% unique  | avg 10.0ch |                                   |
| status                   | INTEGER | unknown   | 0.0% null   | 0.2% unique   | avg 1.0ch  |                                   |
| needs_push               | INTEGER | unknown   | 0.0% null   | 0.2% unique   | avg 1.0ch  |                                   |
| data                     | TEXT    | unknown   | 27.8% null  | 6.6% unique   | avg 24.4ch |                                   |
| timestamp                | INTEGER | timestamp | 0.0% null   | 99.8% unique  | avg 13.0ch | unix_ms [2024-01-01 → 2035-01-01] |
| media_url                | TEXT    | media     | 77.2% null  | 100.0% unique | avg 28.9ch |                                   |
| media_mime_type          | TEXT    | unknown   | 77.2% null  | 2.6% unique   | avg 13.1ch |                                   |
| media_wa_type            | INTEGER | unknown   | 0.0% null   | 0.8% unique   | avg 1.0ch  |                                   |
| media_size               | INTEGER | unknown   | 77.2% null  | 100.0% unique | avg 6.8ch  |                                   |
| media_name               | TEXT    | media     | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| media_caption            | TEXT    | body      | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| latitude                 | REAL    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| longitude                | REAL    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| thumb_image              | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| remote_resource          | TEXT    | sender    | 52.2% null  | 2.1% unique   | avg 15.6ch |                                   |
| received_timestamp       | INTEGER | timestamp | 0.0% null   | 99.8% unique  | avg 13.0ch | unix_ms [2024-01-01 → 2035-01-01] |
| send_timestamp           | INTEGER | timestamp | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| receipt_server_timestamp | INTEGER | timestamp | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| receipt_device_timestamp | INTEGER | timestamp | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| read_device_timestamp    | INTEGER | timestamp | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| played_device_timestamp  | INTEGER | timestamp | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| raw_data                 | BLOB    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| recipient_count          | INTEGER | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| participant_hash         | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| starred                  | INTEGER | unknown   | 0.0% null   | 0.4% unique   | avg 1.0ch  |                                   |
| quoted_row_id            | INTEGER | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| mentioned_jids           | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| multicast_id             | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| edit_version             | INTEGER | unknown   | 0.0% null   | 0.2% unique   | avg 1.0ch  |                                   |
| media_enc_hash           | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| payment_transaction_id   | TEXT    | unknown   | 100.0% null | ? unique      | avg 0.0ch  |                                   |
| forwarded                | INTEGER | unknown   | 0.0% null   | 0.4% unique   | avg 1.0ch  |                                   |
| preview_type             | INTEGER | unknown   | 0.0% null   | 0.2% unique   | avg 1.0ch  |                                   |
| deleted                  | INTEGER | unknown   | 0.0% null   | 0.4% unique   | avg 1.0ch  |                                   |

> ⚠️ **Duplicate fingerprints**: 1 extra rows (1 groups)

#### Table: `sqlite_sequence`
**Rows**: 1

| Column | Type    | Role    | Null      | Unique        | Avg len   | Timestamp info |
| ------ | ------- | ------- | --------- | ------------- | --------- | -------------- |
| name   | UNTYPED | media   | 0.0% null | 100.0% unique | avg 8.0ch |                |
| seq    | UNTYPED | unknown | 0.0% null | 100.0% unique | avg 3.0ch |                |


### `whatsapp_export\wa.db` (12.0 KB)
**Tables**: 1 | **Views**: 0 | **Indexes**: 1

#### Table: `contacts` ⚠️ *likely messages*
**Rows**: 4

| Column       | Type    | Role    | Null       | Unique        | Avg len    | Timestamp info |
| ------------ | ------- | ------- | ---------- | ------------- | ---------- | -------------- |
| _id          | INTEGER | id      | 0.0% null  | 100.0% unique | avg 1.0ch  |                |
| jid          | TEXT    | sender  | 0.0% null  | 100.0% unique | avg 27.8ch |                |
| display_name | TEXT    | media   | 0.0% null  | 100.0% unique | avg 12.0ch |                |
| status       | TEXT    | unknown | 25.0% null | 100.0% unique | avg 10.7ch |                |
| phone_number | TEXT    | unknown | 0.0% null  | 100.0% unique | avg 14.8ch |                |


---
## 3. CSV Files

### `cellebrite_export\messages.csv` (41.4 KB)
**Encoding**: utf-8 | **Delimiter**: `','` | **Rows**: 302

| Column        | Role      | Null  | Unique | Avg len    |
| ------------- | --------- | ----- | ------ | ---------- |
| Source        | sender    | 0.0%  | 0.3%   | avg 8.0ch  |
| MessageType   | unknown   | 0.0%  | 0.7%   | avg 4.1ch  |
| TimeStamp     | timestamp | 0.3%  | 99.7%  | avg 19.0ch |
| Direction     | unknown   | 0.0%  | 0.7%   | avg 8.0ch  |
| From          | sender    | 0.0%  | 1.7%   | avg 15.6ch |
| To            | unknown   | 0.0%  | 1.7%   | avg 15.4ch |
| Body          | body      | 21.5% | 6.3%   | avg 25.5ch |
| Attachments   | unknown   | 91.7% | 100.0% | avg 18.0ch |
| Status        | unknown   | 0.3%  | 1.3%   | avg 6.6ch  |
| Deleted       | unknown   | 0.0%  | 0.7%   | avg 4.8ch  |
| Forwarded     | unknown   | 0.0%  | 0.7%   | avg 4.7ch  |
| ApplicationId | unknown   | 0.0%  | 0.3%   | avg 12.0ch |
| ChatId        | unknown   | 0.0%  | 1.0%   | avg 6.0ch  |

> ⚠️ **Duplicates**: 1 extra rows

---
## 4. JSON Files

### `cellebrite_export\messages.json` (35.0 KB)
**Format**: json_array | **Records**: 100 | **Max depth**: 2

| Key                | Count |
| ------------------ | ----- |
| id                 | 100   |
| chat_id            | 100   |
| sender             | 100   |
| timestamp          | 100   |
| type               | 100   |
| content            | 100   |
| content.text       | 100   |
| content.media_path | 100   |
| metadata           | 100   |
| metadata.deleted   | 100   |
| metadata.forwarded | 100   |
| metadata.starred   | 100   |

---
## 5. XML / UFDR Files

### `cellebrite_export\report.xml` (10.6 KB)
**Root**: `DumpFile` | **Depth**: 3 | **Elements**: 256

| Tag             | Count |
| --------------- | ----- |
| Message         | 50    |
| Timestamp       | 50    |
| Sender          | 50    |
| Body            | 50    |
| Deleted         | 50    |
| DumpFile        | 1     |
| DeviceInfo      | 1     |
| Model           | 1     |
| OS              | 1     |
| IMEI            | 1     |
| InstantMessages | 1     |

---
## 6. Media Files

### Audio
**Count**: 10 | **Total**: 2.8 KB | **Avg**: 282 B | **Zero-byte**: 0

| Extension | Count |
| --------- | ----- |
| .opus     | 10    |

### Images
**Count**: 20 | **Total**: 4.1 KB | **Avg**: 209 B | **Zero-byte**: 1

| Extension | Count |
| --------- | ----- |
| .jpg      | 20    |

### Video
**Count**: 5 | **Total**: 5.2 KB | **Avg**: 1.0 KB | **Zero-byte**: 0

| Extension | Count |
| --------- | ----- |
| .mp4      | 5     |

**Documents / Attachments**: none found
---
## 7. Text / Message Content Analysis

| Metric | Value |
|--------|-------|
| Total messages | 237 |
| Empty messages | 0 (0.0%) |
| Avg length | 25.5 chars |
| Min / Max length | 1 / 38 chars |
| With emoji | 33 (13.9%) |
| With URLs | 17 |
| With phone numbers | 0 |
| With newlines | 0 |
| Media placeholder only | 0 |
| Encoding issues (U+FFFD) | 0 |

### Length distribution

| Bucket    | Count | %      |
| --------- | ----- | ------ |
| 0         | 0     | 0.0%   |
| 1-50      | 237   | 100.0% |
| 51-200    | 0     | 0.0%   |
| 201-500   | 0     | 0.0%   |
| 501-1000  | 0     | 0.0%   |
| 1001-5000 | 0     | 0.0%   |
| >5000     | 0     | 0.0%   |

### Top emoji

| Emoji | Count |
| ----- | ----- |
| 👍     | 20    |
| 💊     | 13    |

---
## 8. Anomalies

- ⚠️ 1 image files are 0 bytes

---
## 9. Importer Hints

- 💡 Likely message table: 'chat_list' in whatsapp_export\msgstore.db (3 rows)
- 💡 Likely message table: 'messages' in whatsapp_export\msgstore.db (504 rows)
- 💡 Likely message table: 'contacts' in whatsapp_export\wa.db (4 rows)
- 💡 Likely message CSV: cellebrite_export\messages.csv (302 rows, body cols: ['Body'])

---
## 10. Open Questions

- ❓ Are media files stored in a flat directory or nested subdirectories?
- ❓ Are audio messages referenced by filename or by a database ID?
- ❓ Are deleted messages present as rows with a flag, or absent entirely?
- ❓ Is there a separate contacts/participant table to resolve sender IDs?
- ❓ Are timestamps stored in UTC or local time? Is timezone stored?
- ❓ Are forwarded messages marked with a specific field or flag?
- ❓ What is the foreign key linking media records to message records?
- ❓ Are group chat participants stored separately from 1-to-1 chats?
