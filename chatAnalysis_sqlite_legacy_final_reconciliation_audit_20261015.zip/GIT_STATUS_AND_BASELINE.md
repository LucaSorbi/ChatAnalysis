# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-15)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Ultimo commit tracciato**: `6c1dc468c4d2fe94e9fcf0963aa36fc48bc9568b`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 `git_diff_sqlite_legacy_reconciliation.patch`).

---

## 2. File Modificati Tracciati e Sintesi delle Correzioni

I seguenti file contengono modifiche rispetto a `HEAD`:

- `analysis/checkpoint.py`:
  - **Correzione 1 (Priorità SQLite e Tolleranza JSON Corrotti)**: Il metodo `load_checkpoint()` carica prioritariamente il record consolidato da SQLite. Se in SQLite è presente un checkpoint valido, l'eventuale presenza su disco di un file legacy JSON malformato o corrotto non causa più il rifiuto della funzione (`None`): il checkpoint valido viene restituito, il file legacy corrotto viene segnalato con diagnostica tecnica sicura e preservato su disco per ispezione senza cancellazione automatica.
  - **Correzione 2 (Cancellazione Completa per Document ID)**: Il metodo `clear_all_for_document_id()` recupera preventivamente da SQLite tutti i `document_fingerprint` associati all'identificativo documentale prima di eseguire la cancellazione. Scansiona i file legacy JSON nella directory per eliminare unicamente quelli appartenenti al `document_id` selezionato o ai suoi fingerprint accertati, senza utilizzare prefissi arbitrari di document ID. Preserva i file appartenenti ad altri documenti e i file corrotti non attribuibili, e impedisce la resurrezione dei checkpoint eliminati da residui su disco.
  - **Correzione 3 (Precedenza Dati Consolidati SQLite e Riconciliazione)**: In `_migrate_legacy_json_if_needed()`, è stata eliminata la clausola distruttiva `ON CONFLICT ... DO UPDATE` che sovrascriveva arbitrariamente i chunk SQLite con dati legacy obsoleti (es. `PRESENT` sovrascritto da `ABSENT`). Il nuovo protocollo ispeziona i chunk esistenti: se identici, mantiene SQLite; se discordanti, stabilisce la precedenza tassativa del dato consolidato in SQLite, segnala il conflitto e preserva il file legacy su disco per audit senza cancellarlo; se in SQLite mancano chunk (SQLite incompleto), inserisce i blocchi mancanti in modo atomico.
- `tests/unit/test_checkpoint_integrity_scalability.py`:
  - **Test 21**: Riproduce fedelmente lo scenario della Correzione 1 (checkpoint SQLite valido non mascherato da JSON legacy corrotto; `has_checkpoint()` coerente; validazione provenance e evidence references superata).
  - **Test 22**: Verifica la cancellazione completa per `document_id` con versioni multiple dello stesso documento, protezione di documenti terzi, preservazione di file corrotti non attribuibili e verifica di assenza di resurrezione post-cancellazione.
  - **Test 23**: Verifica esaustiva degli 8 scenari obbligatori della Correzione 3 (SQLite PRESENT / legacy ABSENT; SQLite ABSENT / legacy PRESENT; risultati identici; SQLite valido / legacy corrotto; legacy valido / SQLite assente; legacy valido / SQLite incompleto; riavvio dello store con dati migrati; nessuna perdita o sovrascrittura silenziosa).
  - Totale test specialistici: **23 su 23 superati**.
- `scripts/generate_sqlite_legacy_reconciliation_patch_utf8.py`: Script di generazione della patch unificata UTF-8.
- `scripts/package_sqlite_legacy_reconciliation_zip.py`: Script di confezionamento dell'archivio di release con verifica CRC e calcolo SHA-256.

---

## 3. Risultati della Suite di Test

- **Pytest completo**: **1756 superati**, 1 saltato, 5 esclusi (benchmark congelati), **0 fallimenti** (in `pytest_and_apptest.log`).
- **Suite Specialistica Integrità e Scalabilità**: **23 su 23 superati**.
- **Streamlit AppTest (`test_apptest_flows.py`)**: **7 su 7 superati**.
- **Packaging e Integrità Wheel (`test_packaging_release.py`)**: **1 su 1 superato** (89 sorgenti Python, import isolato confermato).

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati modificati e i rispettivi hash crittografici SHA-256 corrispondono esattamente:

| File | SHA256 Rilevato | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
