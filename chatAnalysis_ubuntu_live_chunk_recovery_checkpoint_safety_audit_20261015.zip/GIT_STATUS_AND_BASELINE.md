# CHATANALYSIS — STATO GIT E BASELINE DI RIFERIMENTO (RELEASE 2026-10-15 / 2026-10-16)

## 1. Commit Baseline e Riferimento Git

- **Branch attivo**: `main`
- **Baseline di partenza**: `chatAnalysis_sqlite_legacy_reconciliation_hardening_audit_20261015.zip`
- **Politica di rilascio**: Nessun commit né push eseguito autonomamente (modifiche fornite come patch unificata UTF-8 `git_diff_ubuntu_live_chunk_recovery.patch`).

---

## 2. File Modificati Tracciati e Sintesi delle Correzioni

I seguenti file contengono modifiche rispetto alla baseline:

1. `analysis/models.py`:
   - Aggiunto `ChunkLifecycleStatus` (PENDING, RUNNING, SUCCESS, FAILED, RECOVERED_FROM_CHECKPOINT).
   - Introdotto `ChunkDiagnosticCategory` con 16 codici diagnostici granulari conformi alle specifiche.
   - Creata la dataclass `ChunkDiagnosticRecord` con alias retrocompatibili (`model_id`/`model`, `error_type`/`exception_class`, `details`/`error_detail`, `json_valid`/`json_validation_ok`, `schema_valid`/`schema_validation_ok`, `evidence_valid`/`evidence_validation_ok`, `checkpoint_saved`/`checkpoint_save_ok`) e serializzazione biunivoca.
   - Aggiornato `DiscoveryChunkOutcome` con `diagnostic`, `diagnostic_record`, `attempts`, `duration_seconds`.
   - Implementata la funzione `classify_discovery_exception(exc)` per mappare deterministicamente le eccezioni sui codici diagnostici.

2. `ai/topics.py`:
   - Aggiunto un unico retry controllato in `TopicDiscoveryAnalyzer.discover_topics` per `AiInvalidEvidenceCitationError` in modalità operativa (`is_op=True`) con prompt correttivo esplicito che vincola il modello all'uso esclusivo degli evidence ID presenti nel chunk.

3. `analysis/progress.py`:
   - Aggiornato `chunk_failed(..., is_protocol_or_validation=False)` affinché gli errori di validazione/schema incrementino `protocol_errors_count` anziché `http_errors_count`.

4. `analysis/checkpoint.py`:
   - Creata la tabella `checkpoint_chunk_diagnostics` e relativi indici nello store SQLite per la persistenza a lungo termine della diagnostica dei chunk.
   - Implementati `save_chunk_diagnostic` e `get_chunk_diagnostics`.
   - Aggiornati `clear_checkpoint`, `clear_for_document`, e `clear_all_for_document_id` per ripulire contestualmente i record diagnostici associati.
   - Verificata la correzione definitiva del Difetto 1 (isolamento inter-documento contro JSON legacy contraddittori) e del Difetto 2 (validazione atomica preliminare che impedisce migrazioni parziali di legacy non validi).

5. `analysis/service.py`:
   - Aggiornato `run_topic_discovery` per supportare il parametro `retry_failed_only: bool = False` e il tracker opzionale.
   - Integrata la contabilità forense delle evidenze (`total_evidence_count`, `analyzed_evidence_count`, `unanalyzed_evidence_count`).
   - Implementato il tracciamento diagnostico di ciascun chunk in tutti i rami di esecuzione (chunk singolo, subchunk e multi-chunk).
   - Distinti gli errori sistemici di backend (che abortiscono l'analisi) dagli errori transitori di chunk (che marcano il chunk come FAILED e permettono all'analisi di proseguire sugli altri blocchi).

6. `ui/application.py`:
   - Aggiornato `execute_topic_discovery` per propagare il flag `retry_failed_only`.

7. `ui/presentation.py`:
   - Importato `json` e implementata la funzione persistente `render_discovery_diagnostics()`.
   - Integrato il pannello **«Diagnostica analisi»** con alert di copertura parziale, metric card forensi, pulsante **«🔄 Riprova solo i blocchi falliti»**, filtro per blocchi falliti, tabella riassuntiva ed export privo di PII in JSON e CSV.

8. `tests/unit/test_ubuntu_live_chunk_failure_and_recovery.py`:
   - Nuova suite di test sintetici di riproduzione e validazione end-to-end del caso 15/26 riscontrato su Ubuntu (6 test specializzati superati al 100%).

---

## 3. Risultati della Suite di Test

- **Pytest completo**: **1.772 superati**, 1 saltato, 5 esclusi (benchmark congelati), **0 fallimenti** (in `pytest_and_apptest.log`).
- **Nuova Suite Live Ubuntu Recovery (`test_ubuntu_live_chunk_failure_and_recovery.py`)**: **6 su 6 superati**.
- **Suite Specialistica Checkpoint (`test_checkpoint_integrity_scalability.py`)**: **33 su 33 superati**.
- **Streamlit AppTest (`test_apptest_flows.py`)**: **7 su 7 superati**.
- **Verifica Wheel di Distribuzione**: `whatsapp_forensic_importer-0.1.0-py3-none-any.whl` compilata e verificata con `pip install --dry-run`.

---

## 4. Verifica Hash File Scientifici Congelati

I tre file scientifici frozen non sono stati modificati e i rispettivi hash crittografici SHA-256 corrispondono esattamente:

| File | SHA256 Rilevato | SHA256 Atteso (`benchmark_frozen_sha256.txt`) | Esito |
| :--- | :--- | :--- | :---: |
| `ai/experiment.py` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | `91100C0A84CB4A8B7C2EEF34A06CFF9EC21AA6E6EEC14FFD09CE6FEA8BCEE845` | **CONFORME** |
| `ai/benchmark.py` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | `DC57081DBCE3463A8017AA26BB4E4A18889AF0A3296853FE40968561D6D44D36` | **CONFORME** |
| `run_benchmark.sh` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | `7F9CAE97DF2FAE1BC3B5964E639B9F80E3AC5A388EC9C3E20305FF64D48044A7` | **CONFORME** |
