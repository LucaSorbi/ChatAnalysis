class Doc: pass
